#!/bin/bash
# Build the manuscript. Requires all experiments complete and validation
# passing (validate.py is run separately: python3 src/validate.py).
set -e
cd "$(dirname "$0")"
python3 src/analysis.py
python3 src/figures.py
python3 build/equations.py
python3 build/content.py          # refuses to run if validation.json fails
node build/build.js
soffice --headless --convert-to pdf Prompt_Guided_PCG_VR_Exposure_Therapy.docx >/dev/null 2>&1 || \
  python3 /root/.claude/skills/synced/docx/scripts/office/soffice.py --headless --convert-to pdf Prompt_Guided_PCG_VR_Exposure_Therapy.docx
echo "build complete"
