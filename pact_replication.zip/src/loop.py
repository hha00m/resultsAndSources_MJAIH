"""Closed-loop session runner: policy -> path -> safety gate -> PCG ->
virtual patient -> policy observation. One call = one patient's full course.
"""

import numpy as np
from esdl import (base_weights, ladder_theta, theta_to_spec, sample_contract,
                  validate_and_repair, intensity, spec_intensity,
                  spec_theta_vec)
from corpus import (sample_gold_spec, realize, realize_intake)
from compiler import compile_prompt, compile_intake, inject_errors
from pcg import instantiate, realized_intensity, EVENT_SALIENCE
from patient import PatientSim, sample_patient
from policies import make_policy

CFG = dict(T=8, J=8, warmup=0.12, cap_margin=0.02, viol_tol=1e-6)


def _event_cap(cap, events):
    """Effective theta-intensity cap so that dose including event salience
    stays within cap."""
    keep = 1.0
    for e in events:
        keep *= (1.0 - EVENT_SALIENCE.get(e, 0.05))
    return max(0.02, 1.0 - (1.0 - cap) / keep)


def run_patient(domain, patient_idx, policy_name, seed_base=0,
                dynamics='window', eps=0.0, gate_on=True, cfg=None):
    cfg = {**CFG, **(cfg or {})}
    rng_pat = np.random.default_rng(1_000_003 * (seed_base + 1) + patient_idx)
    params = sample_patient(domain, rng_pat, dynamics=dynamics)
    contract = sample_contract(domain, rng_pat)
    intake_text, trig, nontrig = realize_intake(
        domain, np.array(params['m']), rng_pat)

    import hashlib
    key = f"{domain}|{policy_name}|{patient_idx}|{seed_base}|{dynamics}|" \
          f"{round(eps, 3)}|{gate_on}"
    rng_run = np.random.default_rng(
        int(hashlib.sha256(key.encode()).hexdigest()[:15], 16))
    patient = PatientSim(params, rng_run)
    policy = make_policy(policy_name)
    policy.reset(contract, rng_run)
    if policy_name == 'oracle':
        policy.bind(patient)

    w_base = base_weights(domain)
    m_true = np.array(params['m'])
    if policy_name in ('pact', 'pact_point', 'pact_norisk'):
        w_hat = compile_intake(intake_text, domain)
    elif policy_name == 'oracle':
        w_hat = m_true
    else:
        w_hat = w_base
    path_profile = w_hat if policy_name in (
        'pact', 'pact_point', 'pact_norisk', 'oracle') else None

    out = dict(domain=domain, policy=policy_name, idx=patient_idx,
               b0=params['b0'], dynamics=dynamics, eps=eps, gate=gate_on,
               panics=0, trials=0, in_window=0, violations=0,
               distortion=[], sessions=0, dropped=False,
               sessions_to_crit=None, suds_traj=[], i_traj=[])
    crit = params['b0'] + 0.25

    for t in range(cfg['T']):
        if patient.dropped:
            break
        policy.new_session(t)
        b_start = patient.b
        # therapist session prompt: opening scene (kept moderate), context,
        # and possibly one allowed event
        for _ in range(50):
            sp_gold, dims_m, ctx_m = sample_gold_spec(domain, rng_run,
                                                      n_dims=2)
            if spec_intensity(sp_gold) <= 0.35:
                break
        prompt = realize(sp_gold, dims_m, ctx_m, rng_run)
        sess_spec, _ = compile_prompt(prompt, domain)
        if eps > 0:
            sess_spec = inject_errors(sess_spec, domain, eps, rng_run)
        sess_context = sess_spec['context']
        sess_events = list(sess_spec['events'])
        event_trial = rng_run.integers(cfg['J']) if sess_events else -1

        i_prev = cfg['warmup']
        s_list, pan_count = [], 0
        for j in range(cfg['J']):
            cap_t = min(contract['i_cap'],
                        i_prev + contract['ramp']) - cfg['cap_margin']
            cap_t = max(cap_t, 0.03)
            events_j = sess_events if j == event_trial else []
            # scheduled-event dose accounting: the policy budget shrinks so
            # that theta dose + event salience stays at the intended level
            sal_keep = 1.0
            for e in events_j:
                sal_keep *= (1.0 - EVENT_SALIENCE.get(e, 0.05))
            # the policy reasons on its own perceived scale (w_hat); convert
            # the therapist-scale cap onto that scale along the chosen path
            th_cap = ladder_theta(domain, cap_t, w_base, profile=path_profile)
            cap_ctrl = intensity(th_cap, w_hat)
            cap_ctrl_eff = max(0.03, 1.0 - (1.0 - cap_ctrl) / sal_keep)
            if j == 0:
                # session opener comes from the therapist prompt itself
                theta_req = spec_theta_vec(sess_spec)
            else:
                i_tgt = policy.select(cap_ctrl_eff)
                i_tgt_eff = max(0.02, 1.0 - (1.0 - min(i_tgt, cap_ctrl_eff))
                                / sal_keep) if sal_keep < 1.0 else i_tgt
                theta_req = ladder_theta(domain, min(i_tgt_eff, cap_ctrl),
                                         w_hat, profile=path_profile)
            spec = theta_to_spec(domain, theta_req, context=sess_context,
                                 events=events_j)
            if gate_on:
                cap_g = _event_cap(min(contract['i_cap'],
                                       i_prev + contract['ramp'])
                                   - cfg['cap_margin'], spec['events'])
                # bisect theta down if events push effective dose over cap
                safe, rep = validate_and_repair(spec, contract, i_prev=None,
                                                weights=w_base)
                th = np.array([safe['theta'][k] for k in safe['theta']])
                if intensity(th, w_base) > cap_g:
                    lo_, hi_ = 0.0, 1.0
                    for _ in range(50):
                        mid = 0.5 * (lo_ + hi_)
                        if intensity(th * mid, w_base) > cap_g:
                            hi_ = mid
                        else:
                            lo_ = mid
                    th = th * lo_
                    rep['intensity_projected'] = True
                safe = theta_to_spec(domain, th, context=safe['context'],
                                     events=safe['events'])
                out['distortion'].append(rep['distortion'])
            else:
                safe = spec
            scene, th_real, tries = instantiate(safe, rng_run)
            if scene is None:
                continue
            i_nom = realized_intensity(th_real, scene['events'], w_base)
            cap_hard = min(contract['i_cap'], i_prev + contract['ramp'])
            if gate_on:
                # realize-then-verify: the gate checks the REALIZED scene,
                # shrinking and re-instantiating while the realized dose
                # (quantization + placement noise included) overshoots.
                shrink = 1.0
                ev_keep = list(safe['events'])
                for k_try in range(8):
                    if i_nom <= cap_hard:
                        break
                    shrink *= 0.90
                    if k_try >= 2 and ev_keep:
                        ev_keep = []      # defer scripted event: salience
                        shrink = 1.0      # alone can exceed a small ramp cap
                    th_s = np.array([safe['theta'][k]
                                     for k in safe['theta']]) * shrink
                    spec_s = theta_to_spec(domain, th_s,
                                           context=safe['context'],
                                           events=ev_keep)
                    scene2, th2, _ = instantiate(spec_s, rng_run)
                    if scene2 is not None:
                        scene, th_real = scene2, th2
                        i_nom = realized_intensity(th_real, scene['events'],
                                                   w_base)
            if i_nom > cap_hard + cfg['viol_tol'] or \
                    any(e in contract['forbidden'] for e in scene['events']):
                out['violations'] += 1
            i_perc = realized_intensity(th_real, scene['events'], m_true)
            i_ctrl = realized_intensity(th_real, scene['events'], w_hat)
            s, panic = patient.respond(i_perc)
            policy.observe(i_ctrl, s, panic)
            out['trials'] += 1
            out['in_window'] += int(30.0 <= s <= 70.0)
            s_list.append(s)
            out['suds_traj'].append(round(s, 1))
            out['i_traj'].append(round(i_nom, 3))
            i_prev = i_nom
            if panic:
                pan_count += 1
                out['panics'] += 1
                break                      # early session termination
        patient.end_session(s_list, pan_count, b_start)
        out['sessions'] = t + 1
        if out['sessions_to_crit'] is None and patient.b >= crit:
            out['sessions_to_crit'] = t + 1
        if patient.dropped:
            out['dropped'] = True
            break
    out['b_final'] = patient.b
    out['delta_b'] = patient.b - params['b0']
    out['responder'] = int(out['delta_b'] >= 0.25)
    out['distortion'] = float(np.mean(out['distortion'])) if out['distortion'] else 0.0
    return out
