"""Validation suite: every check must pass before the manuscript builds.
Run after all experiments complete: python3 src/validate.py
Writes results/validation.json; build.sh refuses to build if any check fails.
"""

import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, 'results')

DOMS = ['heights', 'spiders', 'social']
CHECKS = []


def check(name, cond, detail=''):
    CHECKS.append({'name': name, 'pass': bool(cond), 'detail': str(detail)})
    print(('PASS' if cond else 'FAIL'), name, detail)


def load(tag):
    with open(os.path.join(RES, tag + '.jsonl')) as f:
        return [json.loads(l) for l in f]


def main():
    with open(os.path.join(RES, 'e1_compiler.json')) as f:
        e1 = json.load(f)
    with open(os.path.join(RES, 'e2_pcg.json')) as f:
        e2 = json.load(f)
    with open(os.path.join(RES, 'summary.json')) as f:
        S = json.load(f)

    # V1 gate property under fuzzing
    check('V1_fuzz_gate', e1['fuzz']['failures'] == 0,
          f"{e1['fuzz']['failures']}/{e1['fuzz']['n']} failures")
    # V2 unsafe prompt interception
    ok = all(e1['unsafe'][d]['caught'] == e1['unsafe'][d]['n'] for d in DOMS)
    check('V2_unsafe_interception', ok, str(e1['unsafe']))
    # V3 no violations in any gated closed-loop condition; violations occur
    # when the gate is off
    gated_viol = 0
    tags = []
    for d in DOMS:
        tags += [f'e3_{d}_{p}' for p in
                 ['fixed', 'staircase', 'random', 'pact', 'oracle']]
        tags += [f'e5_{d}_{p}' for p in
                 ['pact_point', 'pact_norisk', 'pact_generic']]
        tags += [f'e6_{d}_{p}' for p in ['staircase', 'pact', 'oracle']]
        for eps in [0, 10, 20, 30, 50]:
            tags.append(f'e4_{d}_pact_eps{eps:03d}_on')
    for t in tags:
        gated_viol += sum(r['violations'] for r in load(t))
    off_viol = 0
    for d in DOMS:
        for eps in [0, 10, 20, 30, 50]:
            off_viol += sum(r['violations']
                            for r in load(f'e4_{d}_pact_eps{eps:03d}_off'))
    check('V3_gated_zero_violations', gated_viol == 0,
          f'gated={gated_viol}, gate-off={off_viol}')
    check('V3b_gateoff_violations_exist', off_viol > 0, f'off={off_viol}')
    # V4 condition sizes
    sizes_ok = True
    for d in DOMS:
        for p in ['fixed', 'staircase', 'random', 'pact', 'oracle']:
            sizes_ok &= len(load(f'e3_{d}_{p}')) == 400
        for p in ['pact_point', 'pact_norisk', 'pact_generic']:
            sizes_ok &= len(load(f'e5_{d}_{p}')) == 400
        for p in ['staircase', 'pact', 'oracle']:
            sizes_ok &= len(load(f'e6_{d}_{p}')) == 300
        for eps in [0, 10, 20, 30, 50]:
            for g in ['on', 'off']:
                sizes_ok &= len(load(f'e4_{d}_pact_eps{eps:03d}_{g}')) == 150
    check('V4_condition_sizes', sizes_ok)
    # V5 parser ceiling + monotone degradation
    ok = all(abs(e1['per_domain'][d]['f1'] - 1.0) < 1e-9 for d in DOMS)
    mono = True
    for d in DOMS:
        vals = [e1['eps_sweep'][d][k] for k in ['0.0', '0.1', '0.2', '0.3',
                                                '0.5']]
        mono &= all(a >= b - 1e-9 for a, b in zip(vals, vals[1:]))
    check('V5_parser_ceiling_and_monotone', ok and mono)
    # V6 PCG calibration
    ok = all(e2[d]['spearman'] > 0.95 and e2[d]['rmse'] < 0.03 for d in DOMS)
    check('V6_pcg_calibration', ok,
          {d: round(e2[d]['rmse'], 4) for d in DOMS})
    # V7 ordering sanity (window dynamics, pooled)
    def pooled_db(p):
        v = []
        for d in DOMS:
            v += [r['delta_b'] for r in load(f'e3_{d}_{p}')]
        return float(np.mean(v))
    dbs = {p: pooled_db(p) for p in
           ['fixed', 'staircase', 'random', 'pact', 'oracle']}
    check('V7_ordering', dbs['oracle'] >= dbs['pact'] - 0.01
          and dbs['pact'] > dbs['random'] + 0.05,
          {k: round(v, 3) for k, v in dbs.items()})
    # V8 record internal consistency
    ok = True
    for d in DOMS:
        for r in load(f'e3_{d}_pact'):
            ok &= abs((r['b_final'] - r['b0']) - r['delta_b']) < 1e-9
            ok &= r['responder'] == int(r['delta_b'] >= 0.25)
    check('V8_record_consistency', ok)
    # V9 summary derivability: recompute one condition aggregate
    import analysis
    recs = load('e3_heights_pact')
    a = analysis.agg(recs)
    s = S['e3']['heights']['pact']
    ok = all(abs(a[k] - s[k]) < 1e-9 for k in
             ['delta_b_mean', 'responder', 'dropout'] if s[k] is not None)
    check('V9_summary_rederives', ok)
    # V10 intake estimate beats generic prior
    ok = all(e1['intake'][d]['cosine_mean'] >= e1['intake'][d]['cosine_base']
             for d in DOMS)
    check('V10_intake_beats_base', ok,
          {d: (round(e1['intake'][d]['cosine_mean'], 3),
               round(e1['intake'][d]['cosine_base'], 3)) for d in DOMS})
    # V11 ladder monotone consistency: I(theta(i)) == i
    from esdl import ladder_theta, base_weights, intensity, max_intensity
    ok = True
    for d in DOMS:
        w = base_weights(d)
        imax = max_intensity(w)
        for i_t in np.linspace(0.05, 0.8, 12):
            tgt = min(i_t, imax - 1e-9)   # ladder saturates at the domain
            ok &= abs(intensity(ladder_theta(d, i_t, w), w) - tgt) < 1e-4
    check('V11_ladder_inverse', ok)
    # V12 particle filter recovers b on a synthetic patient
    from patient import PatientSim, sample_patient
    from policies import PactController
    rng = np.random.default_rng(4)
    params = sample_patient('heights', rng)
    pt = PatientSim(params, rng)
    pf = PactController()
    from esdl import default_contract
    pf.reset(default_contract('heights'), rng)
    errs = []
    for t in range(40):
        i = min(0.85, max(0.05, pt.b + rng.normal(0, 0.15)))
        s, pan = pt.respond(i)
        pf.observe(i, s, pan)
        errs.append(abs(float(np.sum(pf.w * pf.pb)) - pt.b))
    check('V12_pf_recovers_b', np.mean(errs[-10:]) < 0.10,
          f'mean |b_hat-b| last10 = {np.mean(errs[-10:]):.3f}')
    # V13 determinism of the closed loop
    from loop import run_patient
    r1 = run_patient('spiders', 11, 'pact')
    r2 = run_patient('spiders', 11, 'pact')
    check('V13_determinism', r1['delta_b'] == r2['delta_b']
          and r1['suds_traj'] == r2['suds_traj'])

    n_fail = sum(1 for c in CHECKS if not c['pass'])
    out = {'checks': CHECKS, 'n_fail': n_fail}
    with open(os.path.join(RES, 'validation.json'), 'w') as f:
        json.dump(out, f, indent=1)
    print(f'{len(CHECKS) - n_fail}/{len(CHECKS)} checks pass')
    sys.exit(1 if n_fail else 0)


if __name__ == '__main__':
    main()
