"""Virtual-patient model for closed-loop simulation.

State: fear tolerance b in [0,1] (the intensity at which expected SUDS
crosses 50), reactivity a, panic threshold s_pan, habituation rate eta_h,
sensitization rate eta_s, between-session return-of-fear rho, dropout
coefficients, and a trigger-weight profile m over the domain's exposure
dimensions (patient-perceived intensity uses m, not the base weights).

Two learning dynamics:
  'window'  (default; emotional-processing style): corrective learning
            occurs when SUDS falls in an activation window, peaking at 55.
  'pe'      (inhibitory-learning style, for the misspecification study):
            learning is driven by expectancy violation ie the positive gap
            between expected and experienced distress; expectation is a
            running estimate initialized pessimistically.

All SUDS are on the 0-100 scale. One trial ~ one sustained exposure step.
"""

import numpy as np
from corpus import sample_trigger_profile

SUDS_NOISE = 6.0
WINDOW_LO, WINDOW_PEAK, WINDOW_HI = 30.0, 55.0, 80.0


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def sample_patient(domain, rng, dynamics='window'):
    return {
        'domain': domain, 'dynamics': dynamics,
        'b0': float(np.clip(rng.beta(2.2, 4.5) * 0.7 + 0.05, 0.05, 0.60)),
        'a': float(rng.uniform(5.0, 11.0)),
        's_pan': float(rng.uniform(78.0, 94.0)),
        'eta_h': float(rng.uniform(0.008, 0.038)),
        'eta_s': float(rng.uniform(0.06, 0.30)),
        'rho': float(rng.uniform(0.15, 0.45)),
        'm': sample_trigger_profile(domain, rng).tolist(),
        # dropout logit coefficients (per session)
        'd0': -3.0, 'd_pan': 1.5, 'd_dist': 1.8, 'd_fut': 1.4, 'd_prog': 2.0,
        'd_tot': 1.5,
    }


def learning_gain(s):
    """Window kernel g(s): peaked at WINDOW_PEAK, near-zero when the
    exposure is trivial, small above the window (aroused but overwhelmed)."""
    s = np.asarray(s, float)
    g = np.exp(-((s - WINDOW_PEAK) / 18.0) ** 2)
    return np.where(s < 20.0, 0.02, np.where(s > WINDOW_HI, 0.10, g))


class PatientSim:
    def __init__(self, params, rng):
        self.p = dict(params)
        self.rng = rng
        self.b = params['b0']
        self.m = np.array(params['m'])
        self.expect = 85.0            # running distress expectancy (legacy)
        # pe dynamics: belief about own tolerance, pessimistically low;
        # distress expected for a dose i is 100*sigmoid(a*(i - b_hat))
        self.b_hat0 = max(0.02, params['b0'] - 0.10)
        self.b_hat = self.b_hat0
        self.dropped = False
        self.log = []

    def perceived_intensity(self, realized_theta, events):
        from pcg import realized_intensity
        return realized_intensity(realized_theta, events, self.m)

    def respond(self, i_perceived):
        """One exposure trial at perceived dose i. Returns (suds, panic)."""
        p = self.p
        xi = self.rng.normal(0, SUDS_NOISE / 100.0 * p['a'])
        s = 100.0 * sigmoid(p['a'] * (i_perceived - self.b) + xi)
        panic = s >= p['s_pan']
        if panic:
            self.b = max(0.02, self.b - p['eta_s'] * (s - p['s_pan'] + 15.0) / 100.0)
        else:
            if p['dynamics'] == 'window':
                self.b = min(1.0, self.b + p['eta_h'] * float(learning_gain(s)))
            else:
                # inhibitory-learning / expectancy-violation dynamics:
                # expected distress for THIS dose comes from a pessimistic
                # belief b_hat about one's own tolerance; learning follows
                # the positive gap between expected and experienced distress
                # (near-zero for trivial doses, near-zero when both
                # saturate, peaked in between).
                e_hat = 100.0 * sigmoid(p['a'] * (i_perceived - self.b_hat))
                viol = max(0.0, e_hat - s)
                self.b = min(1.0, self.b + p['eta_h'] * viol / 40.0)
                # belief consolidates toward actual tolerance after clear
                # violations, barely otherwise
                rate = 0.20 if viol > 5.0 else 0.04
                self.b_hat = self.b_hat + rate * (self.b - self.b_hat)
        self.expect = 0.75 * self.expect + 0.25 * s
        return float(s), bool(panic)

    def end_session(self, session_suds, session_panics, b_session_start):
        """Between-session consolidation + dropout draw."""
        p = self.p
        if p['dynamics'] == 'pe':
            # partial expectancy renewal between sessions (return of the
            # pessimistic belief)
            self.b_hat = self.b_hat - 0.25 * (self.b_hat - self.b_hat0)
        gain = self.b - b_session_start
        if gain > 0:
            self.b = b_session_start + (1.0 - p['rho']) * gain
        s_arr = np.array(session_suds) if session_suds else np.array([0.0])
        dist = float((s_arr > 70).mean())
        fut = float((s_arr < 20).mean())
        prog = float(np.clip(gain / 0.05, 0.0, 1.0))
        tot = float(np.clip((self.b - p['b0']) / 0.30, 0.0, 1.0))
        z = (p['d0'] + p['d_pan'] * min(session_panics, 3)
             + p['d_dist'] * dist + p['d_fut'] * fut - p['d_prog'] * prog
             - p['d_tot'] * tot)
        if self.rng.random() < sigmoid(z):
            self.dropped = True
        return self.dropped
