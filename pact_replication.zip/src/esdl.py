"""ESDL: Exposure Scenario Description Language.

A scene specification is a typed record:
    spec = {
        'domain':  'heights' | 'spiders' | 'social',
        'theta':   dict dim_name -> float in [0,1]   (exposure dimensions)
        'context': dict slot -> categorical value     (non-exposure slots)
        'events':  list of event names                (scripted events)
    }

Intensity model (Eq. in paper): noisy-OR aggregation
    I(theta; w) = 1 - prod_k (1 - w_k * theta_k)
with domain base weights w (sum of w gives max attainable intensity < 1
complement). Patient-perceived intensity uses patient weights m instead of w.

Safety contract (therapist-authored, per patient):
    bounds:     dim -> (lo, hi)
    forbidden:  set of event names
    i_cap:      absolute intensity ceiling
    ramp:       max increase of I between consecutive trials
    session_cap: max trials per session (enforced by the session loop)

validate_and_repair() is the single gate through which every spec must pass
before instantiation; it clips bounds, strips forbidden events, and projects
intensity onto [0, min(i_cap, i_prev + ramp)] by uniform down-scaling of
theta (a monotone bisection, since I is monotone in each theta_k).
"""

import numpy as np

# ---------------------------------------------------------------- domains

DOMAINS = {
    'heights': {
        'dims': ['elevation', 'edge_proximity', 'barrier_openness',
                 'surface_instability', 'wind_motion'],
        'weights': {'elevation': 0.42, 'edge_proximity': 0.28,
                    'barrier_openness': 0.34, 'surface_instability': 0.20,
                    'wind_motion': 0.12},
        'context': {
            'setting': ['indoor_mezzanine', 'balcony', 'office_window',
                        'rooftop', 'bridge', 'cliff_trail', 'glass_platform'],
            'time_of_day': ['morning', 'midday', 'dusk'],
            'ambient': ['quiet', 'street_noise', 'crowd_noise'],
        },
        'events': ['gust_of_wind', 'object_drop', 'railing_rattle',
                   'bird_flyby', 'platform_tilt', 'forced_fall'],
    },
    'spiders': {
        'dims': ['size', 'proximity', 'count', 'movement_speed',
                 'unpredictability'],
        'weights': {'size': 0.30, 'proximity': 0.40, 'count': 0.22,
                    'movement_speed': 0.24, 'unpredictability': 0.18},
        'context': {
            'setting': ['terrarium_room', 'kitchen', 'garden_shed',
                        'basement', 'bedroom'],
            'lighting': ['bright', 'normal', 'dim'],
            'ambient': ['quiet', 'house_noise'],
        },
        'events': ['web_drop', 'sudden_dart', 'towards_walk',
                   'rustle_sound', 'contact_touch', 'swarm_release'],
    },
    'social': {
        'dims': ['audience_size', 'gaze_proportion', 'evaluative_negativity',
                 'interruption_rate', 'task_difficulty'],
        'weights': {'audience_size': 0.34, 'gaze_proportion': 0.26,
                    'evaluative_negativity': 0.32, 'interruption_rate': 0.20,
                    'task_difficulty': 0.18},
        'context': {
            'setting': ['empty_meeting_room', 'small_meeting', 'classroom',
                        'seminar_hall', 'auditorium', 'wedding_reception'],
            'familiarity': ['friends', 'colleagues', 'strangers'],
            'ambient': ['quiet', 'murmur', 'phone_rings'],
        },
        'events': ['pointed_question', 'audience_laugh', 'walkout',
                   'phone_interruption', 'mic_failure', 'open_mockery'],
    },
}

# events that a typical contract forbids (aversive / therapeutically contraindicated)
DEFAULT_FORBIDDEN = {
    'heights': {'forced_fall', 'platform_tilt'},
    'spiders': {'contact_touch', 'swarm_release'},
    'social':  {'open_mockery', 'walkout'},
}


def base_weights(domain):
    d = DOMAINS[domain]
    return np.array([d['weights'][k] for k in d['dims']])


def intensity(theta_vec, weights):
    """Noisy-OR intensity aggregation. theta_vec, weights: arrays over dims."""
    theta_vec = np.clip(theta_vec, 0.0, 1.0)
    return float(1.0 - np.prod(1.0 - weights * theta_vec))


def max_intensity(weights):
    return float(1.0 - np.prod(1.0 - weights))


def spec_theta_vec(spec):
    dims = DOMAINS[spec['domain']]['dims']
    return np.array([spec['theta'].get(k, 0.0) for k in dims])


def spec_intensity(spec, weights=None):
    w = base_weights(spec['domain']) if weights is None else weights
    return intensity(spec_theta_vec(spec), w)


def default_spec(domain):
    d = DOMAINS[domain]
    return {
        'domain': domain,
        'theta': {k: 0.0 for k in d['dims']},
        'context': {slot: vals[0] for slot, vals in d['context'].items()},
        'events': [],
    }


# ---------------------------------------------------------------- contract

def default_contract(domain, i_cap=0.85, ramp=0.15):
    d = DOMAINS[domain]
    return {
        'domain': domain,
        'bounds': {k: (0.0, 1.0) for k in d['dims']},
        'forbidden': set(DEFAULT_FORBIDDEN[domain]),
        'i_cap': i_cap,
        'ramp': ramp,
        'session_cap': 12,
    }


def sample_contract(domain, rng):
    """Therapist-authored contract with plausible per-patient variation."""
    c = default_contract(domain,
                         i_cap=float(rng.uniform(0.70, 0.92)),
                         ramp=float(rng.uniform(0.10, 0.22)))
    dims = DOMAINS[domain]['dims']
    # one randomly chosen dimension is capped harder (a known individual limit)
    k = dims[rng.integers(len(dims))]
    c['bounds'][k] = (0.0, float(rng.uniform(0.55, 0.9)))
    # occasionally an extra event is forbidden for this patient
    allowed = [e for e in DOMAINS[domain]['events'] if e not in c['forbidden']]
    if rng.random() < 0.5 and allowed:
        c['forbidden'].add(allowed[rng.integers(len(allowed))])
    return c


def validate_and_repair(spec, contract, i_prev=None, weights=None,
                        mode='repair'):
    """The safety gate. Returns (safe_spec, report).

    mode='repair': clip + strip + project intensity (bisection on scale t).
    mode='reject': if any violation, return None spec (caller falls back).
    report: dict with flags and distortion (L2 on theta, weighted by w).
    """
    d = DOMAINS[spec['domain']]
    w = base_weights(spec['domain']) if weights is None else weights
    cap = contract['i_cap'] if i_prev is None else min(
        contract['i_cap'], i_prev + contract['ramp'])
    cap = max(cap, 0.0)

    report = {'bounds_clipped': False, 'events_stripped': 0,
              'intensity_projected': False, 'distortion': 0.0,
              'violated': False}

    theta0 = spec_theta_vec(spec)
    lo = np.array([contract['bounds'][k][0] for k in d['dims']])
    hi = np.array([contract['bounds'][k][1] for k in d['dims']])
    theta = np.clip(theta0, lo, hi)
    if np.any(np.abs(theta - np.clip(theta0, 0, 1)) > 1e-12):
        report['bounds_clipped'] = True
        report['violated'] = True

    events = [e for e in spec['events'] if e not in contract['forbidden']]
    stripped = len(spec['events']) - len(events)
    if stripped:
        report['events_stripped'] = stripped
        report['violated'] = True

    if intensity(theta, w) > cap + 1e-9:
        report['intensity_projected'] = True
        report['violated'] = True
        if mode == 'reject':
            return None, report
        t_lo, t_hi = 0.0, 1.0
        for _ in range(60):
            t = 0.5 * (t_lo + t_hi)
            if intensity(theta * t, w) > cap:
                t_hi = t
            else:
                t_lo = t
        theta = np.clip(theta * t_lo, lo, None)  # lo bounds are 0 in practice

    if mode == 'reject' and report['violated']:
        return None, report

    report['distortion'] = float(np.sqrt(np.sum(w * (theta - theta0) ** 2)))
    safe = {
        'domain': spec['domain'],
        'theta': {k: float(v) for k, v in zip(d['dims'], theta)},
        'context': dict(spec['context']),
        'events': events,
    }
    return safe, report


# ------------------------------------------------- intensity -> theta paths

def ladder_theta(domain, i_target, weights=None, profile=None):
    """Canonical escalation path theta(I): distribute exposure across
    dimensions proportional to a direction u (base weights by default,
    or a personalized trigger profile), scaled so that I(theta)=i_target.

    Monotone in i_target; solved by bisection on the path parameter.
    """
    w = base_weights(domain) if weights is None else weights
    u = w.copy() if profile is None else np.asarray(profile, float)
    u = np.clip(u, 1e-6, None)
    u = u / u.max()

    def path(t):
        return np.clip(t * u, 0.0, 1.0)

    imax = intensity(path(1.0 / u.min() if u.min() > 0 else 1.0), w)
    # bisection over t in [0, t_max] where all dims saturate
    t_hi_max = 1.0 / u.min()
    i_target = min(i_target, imax - 1e-9)
    t_lo, t_hi = 0.0, t_hi_max
    for _ in range(60):
        t = 0.5 * (t_lo + t_hi)
        if intensity(path(t), w) < i_target:
            t_lo = t
        else:
            t_hi = t
    return path(0.5 * (t_lo + t_hi))


def theta_to_spec(domain, theta_vec, context=None, events=None):
    d = DOMAINS[domain]
    sp = default_spec(domain)
    sp['theta'] = {k: float(v) for k, v in zip(d['dims'], np.clip(theta_vec, 0, 1))}
    if context:
        sp['context'].update(context)
    if events:
        sp['events'] = list(events)
    return sp
