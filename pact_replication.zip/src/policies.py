"""Exposure-progression policies. All policies emit a target nominal
intensity i in [0,1] (measured with the therapist/base weights); the session
loop maps i to a scene via the escalation path, the safety gate, and PCG.

Interface:
    reset(contract)                 -> None      (new patient)
    new_session(session_index)      -> None
    select(i_prev_cap)              -> i_target  (<= i_prev_cap by contract)
    observe(i_nominal, suds, panic) -> None
"""

import numpy as np
from patient import sigmoid, learning_gain, SUDS_NOISE

RNG_JITTER = dict(a=0.15, b=0.008, s_pan=0.8, eta_h=0.002, eta_s=0.008,
                  rho=0.01)


def _logit(p):
    p = np.clip(p, 1e-4, 1 - 1e-4)
    return np.log(p / (1 - p))


try:
    from scipy.special import ndtr as _phi          # vectorized normal CDF
except Exception:                                    # pragma: no cover
    from math import erf

    def _phi(z):
        return 0.5 * (1.0 + np.vectorize(erf)(np.asarray(z) / np.sqrt(2.0)))


class FixedLadder:
    """Standard graded hierarchy: fixed rungs, advance on low distress,
    retreat one rung after panic."""

    name = 'fixed'

    def reset(self, contract, rng):
        self.rungs = np.linspace(0.08, contract['i_cap'], 12)
        self.k = 0
        self.rng = rng

    def new_session(self, t):
        self.k = max(0, self.k - 1) if t > 0 else self.k  # gentle re-entry

    def select(self, i_cap_t):
        return float(min(self.rungs[self.k], i_cap_t))

    def observe(self, i, s, panic):
        if panic:
            self.k = max(0, self.k - 1)
        elif s < 40.0:
            self.k = min(len(self.rungs) - 1, self.k + 1)


class Staircase:
    """SUDS-driven up/down staircase targeting the 35-70 window."""

    name = 'staircase'

    def reset(self, contract, rng):
        self.i = 0.15
        self.cap = contract['i_cap']
        self.rng = rng

    def new_session(self, t):
        self.i = max(0.12, self.i - 0.10)

    def select(self, i_cap_t):
        return float(np.clip(self.i, 0.02, i_cap_t))

    def observe(self, i, s, panic):
        if panic:
            self.i = max(0.05, i - 0.20)
        elif s < 35.0:
            self.i = min(self.cap, i + 0.06)
        elif s > 70.0:
            self.i = max(0.05, i - 0.10)
        else:
            self.i = i


class RandomPolicy:
    name = 'random'

    def reset(self, contract, rng):
        self.cap = contract['i_cap']
        self.rng = rng

    def new_session(self, t):
        pass

    def select(self, i_cap_t):
        return float(self.rng.uniform(0.02, max(i_cap_t, 0.03)))

    def observe(self, i, s, panic):
        pass


class PactController:
    """Particle-filter posterior over patient parameters + risk-constrained
    myopic dose selection under the assumed window-learning model."""

    def __init__(self, n_particles=600, delta=0.03, point_estimate=False,
                 risk_constraint=True, name='pact'):
        self.P = n_particles
        self.delta = delta
        self.point = point_estimate
        self.riskc = risk_constraint
        self.name = name

    def reset(self, contract, rng):
        self.rng = rng
        self.cap = contract['i_cap']
        P = self.P
        self.pa = rng.uniform(4.5, 11.5, P)
        self.pb = np.clip(rng.beta(2.2, 4.5, P) * 0.7 + 0.05, 0.05, 0.60)
        self.ps = rng.uniform(76.0, 96.0, P)
        self.ph = rng.uniform(0.010, 0.055, P)
        self.pe_ = rng.uniform(0.05, 0.32, P)
        self.pr = rng.uniform(0.08, 0.42, P)
        self.w = np.full(P, 1.0 / P)
        self.b_sess_start = self.pb.copy()

    def new_session(self, t):
        if t > 0:
            gain = self.pb - self.b_sess_start
            self.pb = np.where(gain > 0,
                               self.b_sess_start + (1 - self.pr) * gain,
                               self.pb)
        self.b_sess_start = self.pb.copy()

    def _predict(self, i):
        mu = self.pa * (i - self.pb)              # logit-SUDS mean
        sd = SUDS_NOISE / 100.0 * self.pa
        return mu, sd

    def _panic_prob(self, i):
        mu, sd = self._predict(i)
        thr = _logit(self.ps / 100.0)
        return 1.0 - _phi((thr - mu) / sd)

    def select(self, i_cap_t):
        grid = np.linspace(0.02, max(i_cap_t, 0.03), 25)
        if self.point:
            a = float(np.sum(self.w * self.pa)); b = float(np.sum(self.w * self.pb))
            sp = float(np.sum(self.w * self.ps)); eh = float(np.sum(self.w * self.ph))
            es = float(np.sum(self.w * self.pe_))
            best_i, best_v = grid[0], -1e9
            for i in grid:
                mu = a * (i - b); sd = SUDS_NOISE / 100.0 * a
                p_pan = 1.0 - _phi((_logit(sp / 100.0) - mu) / sd)
                s_hat = 100.0 * sigmoid(mu)
                v = (1 - p_pan) * eh * float(learning_gain(s_hat)) \
                    - p_pan * es * 0.12
                if self.riskc and p_pan > self.delta:
                    continue
                if v >= best_v:      # tie-break high: climb the ramp when flat
                    best_v, best_i = v, i
            return float(best_i)
        best_i, best_v = grid[0], -1e9
        for i in grid:
            mu, sd = self._predict(i)
            p_pan = self._panic_prob(i)
            s_hat = 100.0 * sigmoid(mu)
            gain = (1 - p_pan) * self.ph * learning_gain(s_hat) \
                - p_pan * self.pe_ * 0.12
            ev = float(np.sum(self.w * gain))
            risk = float(np.sum(self.w * p_pan))
            if self.riskc and risk > self.delta:
                continue
            if ev >= best_v:         # tie-break high: climb the ramp when flat
                best_v, best_i = ev, i
        return float(best_i)

    def observe(self, i, s, panic):
        s = float(np.clip(s, 1.0, 99.0))
        y = _logit(s / 100.0)
        mu, sd = self._predict(i)
        ll = np.exp(-0.5 * ((y - mu) / sd) ** 2) / sd
        # panic indicator consistency
        pan_pred = s >= self.ps if panic else s < self.ps
        ll = ll * np.where(pan_pred, 1.0, 0.25)
        self.w *= ll + 1e-300
        self.w /= self.w.sum()
        # state transition with observed outcome, per-particle params
        if panic:
            self.pb = np.maximum(0.02, self.pb - self.pe_ * (s - self.ps + 5.0)
                                 .clip(0.0) / 100.0)
        else:
            self.pb = np.minimum(1.0, self.pb + self.ph * float(learning_gain(s)))
        ess = 1.0 / np.sum(self.w ** 2)
        if ess < self.P / 2:
            idx = self._systematic_resample()
            for attr, jit in [('pa', 'a'), ('pb', 'b'), ('ps', 's_pan'),
                              ('ph', 'eta_h'), ('pe_', 'eta_s'), ('pr', 'rho')]:
                v = getattr(self, attr)[idx] + self.rng.normal(
                    0, RNG_JITTER[jit], self.P)
                setattr(self, attr, v)
            self.pa = np.clip(self.pa, 3.5, 13.0)
            self.pb = np.clip(self.pb, 0.02, 1.0)
            self.ps = np.clip(self.ps, 70.0, 98.0)
            self.ph = np.clip(self.ph, 0.005, 0.07)
            self.pe_ = np.clip(self.pe_, 0.02, 0.40)
            self.pr = np.clip(self.pr, 0.02, 0.55)
            self.b_sess_start = self.b_sess_start[idx]
            self.w = np.full(self.P, 1.0 / self.P)

    def _systematic_resample(self):
        pos = (self.rng.random() + np.arange(self.P)) / self.P
        return np.searchsorted(np.cumsum(self.w), pos).clip(0, self.P - 1)


class Oracle:
    """Full-knowledge myopic planner: true parameters, true current state,
    true dynamics; same risk constraint as PACT. Upper reference, not a
    deployable policy."""

    name = 'oracle'

    def __init__(self, delta=0.03):
        self.delta = delta

    def bind(self, patient):
        self.pt = patient

    def reset(self, contract, rng):
        self.cap = contract['i_cap']
        self.rng = rng

    def new_session(self, t):
        pass

    def select(self, i_cap_t):
        pt = self.pt
        p = pt.p
        grid = np.linspace(0.02, max(i_cap_t, 0.03), 40)
        sd = SUDS_NOISE / 100.0 * p['a']
        thr = _logit(p['s_pan'] / 100.0)
        best_i, best_v = grid[0], -1e9
        for i in grid:
            mu = p['a'] * (i - pt.b)
            p_pan = 1.0 - _phi((thr - mu) / sd)
            if p_pan > self.delta:
                continue
            s_hat = 100.0 * sigmoid(mu)
            if p['dynamics'] == 'window':
                gain = p['eta_h'] * float(learning_gain(s_hat))
            else:
                e_hat = 100.0 * sigmoid(p['a'] * (i - pt.b_hat))
                gain = p['eta_h'] * max(0.0, e_hat - s_hat) / 40.0
            v = (1 - p_pan) * gain - p_pan * p['eta_s'] * 0.12
            if v >= best_v:          # tie-break high: climb the ramp when flat
                best_v, best_i = v, i
        return float(best_i)

    def observe(self, i, s, panic):
        pass


def make_policy(name):
    if name == 'fixed':
        return FixedLadder()
    if name == 'staircase':
        return Staircase()
    if name == 'random':
        return RandomPolicy()
    if name == 'pact':
        return PactController()
    if name == 'pact_point':
        return PactController(point_estimate=True, name='pact_point')
    if name == 'pact_norisk':
        return PactController(risk_constraint=False, name='pact_norisk')
    if name == 'pact_generic':
        return PactController(name='pact_generic')   # path handled by loop
    if name == 'oracle':
        return Oracle()
    raise ValueError(name)
