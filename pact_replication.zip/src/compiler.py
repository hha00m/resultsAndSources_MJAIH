"""Prompt -> ESDL compiler (deterministic reference front-end) and the
error-injection model for imperfect front-ends.

The compiler is a longest-match lexicon parser: every surface form in the
shared lexicon is indexed; the prompt is scanned for non-overlapping matches
preferring longer phrases; matched slots overwrite the carry-over spec
(previous scene or domain default). It is deliberately simple, fully
inspectable, and LLM-agnostic: any model that emits ESDL slots can replace
it behind the same safety gate.
"""

import re
import numpy as np
from esdl import DOMAINS, default_spec
from lexicon import DIM_LEVELS, CONTEXT_SURFACES, EVENT_SURFACES
from corpus import TRIGGER_PHRASES


def _norm(s):
    return re.sub(r'\s+', ' ', s.lower().replace('’', "'")).strip()


def _build_index(domain):
    d = DOMAINS[domain]
    idx = []  # (surface, kind, key, value)
    for dim in d['dims']:
        for val, forms in DIM_LEVELS[dim]:
            for f in forms:
                idx.append((_norm(f), 'dim', dim, val))
    for slot, vals in d['context'].items():
        for v in vals:
            for f in CONTEXT_SURFACES[slot][v]:
                idx.append((_norm(f), 'ctx', slot, v))
    for ev in d['events']:
        for f in EVENT_SURFACES[ev]:
            idx.append((_norm(f), 'event', ev, None))
    idx.sort(key=lambda r: -len(r[0]))
    return idx


_INDEX = {dom: _build_index(dom) for dom in DOMAINS}


def compile_prompt(prompt, domain, prev_spec=None):
    """Parse prompt into a spec, starting from prev_spec (carry-over) or
    the domain default. Returns (spec, matches)."""
    text = _norm(prompt)
    base = prev_spec if prev_spec is not None else default_spec(domain)
    spec = {'domain': domain,
            'theta': dict(base['theta']),
            'context': dict(base['context']),
            'events': []}
    used = np.zeros(len(text), bool)
    matches = []
    for surface, kind, key, val in _INDEX[domain]:
        start = 0
        while True:
            i = text.find(surface, start)
            if i < 0:
                break
            j = i + len(surface)
            if not used[i:j].any():
                used[i:j] = True
                matches.append((kind, key, val))
            start = j
    for kind, key, val in matches:
        if kind == 'dim':
            spec['theta'][key] = val
        elif kind == 'ctx':
            spec['context'][key] = val
        elif kind == 'event':
            spec['events'].append(key)
    return spec, matches


def compile_intake(text, domain):
    """Intake prompt -> trigger profile prior (weight multipliers)."""
    from esdl import base_weights
    t = _norm(text)
    dims = DOMAINS[domain]['dims']
    w = base_weights(domain).copy()
    m = w.copy()
    # polarity is anchored to the phrase occurrence itself: a mentioned
    # trigger is amplified unless the local syntax marks it as the
    # explicitly discounted dimension
    for k, dim in enumerate(dims):
        ph = _norm(TRIGGER_PHRASES[dim])
        i = t.find(ph)
        if i < 0:
            continue
        pre = t[max(0, i - 16): i]
        post = t[i + len(ph): i + len(ph) + 24]
        if ('more than' in pre or post.startswith(' barely registers')
                or post.startswith(' has never bothered')):
            m[k] = w[k] * 0.35
        else:
            m[k] = min(0.85, w[k] * 1.9)
    return m


# ------------------------------------------------------------ error injection

def inject_errors(spec, domain, eps, rng, gold_mentioned=None):
    """Simulate an imperfect LLM front-end operating at slot error rate eps.

    Per exposure dimension: with prob eps, either substitute a random level
    (60%), or reset to default 0 (40%, 'deletion'). Per context slot: with
    prob eps substitute. Events: with prob eps drop each event; with prob
    eps/2 hallucinate one random event from the domain inventory (which may
    be forbidden -- exactly the case the safety gate exists for).
    """
    d = DOMAINS[domain]
    out = {'domain': domain, 'theta': dict(spec['theta']),
           'context': dict(spec['context']), 'events': list(spec['events'])}
    for dim in d['dims']:
        if rng.random() < eps:
            if rng.random() < 0.6:
                levels = DIM_LEVELS[dim]
                out['theta'][dim] = levels[rng.integers(len(levels))][0]
            else:
                out['theta'][dim] = 0.0
    for slot, vals in d['context'].items():
        if rng.random() < eps:
            out['context'][slot] = vals[rng.integers(len(vals))]
    out['events'] = [e for e in out['events'] if rng.random() >= eps]
    if rng.random() < eps / 2:
        out['events'].append(d['events'][rng.integers(len(d['events']))])
    return out


# ------------------------------------------------------------------ scoring

def score_spec(pred, gold, domain, tol=0.01):
    """Slot-level scoring. Returns dict with per-family accuracy and
    micro F1 over asserted slots (non-default dims + context + events)."""
    d = DOMAINS[domain]
    dflt = default_spec(domain)
    tp = fp = fn = 0
    dim_ok = dim_tot = 0
    for dim in d['dims']:
        g, p = gold['theta'][dim], pred['theta'][dim]
        g_as, p_as = abs(g - dflt['theta'][dim]) > tol, abs(p - dflt['theta'][dim]) > tol
        if g_as or p_as:
            dim_tot += 1
            if abs(g - p) <= tol:
                dim_ok += 1
        if g_as and p_as and abs(g - p) <= tol:
            tp += 1
        elif p_as and (not g_as or abs(g - p) > tol):
            fp += 1
        if g_as and (not p_as or abs(g - p) > tol):
            fn += 1
    ctx_ok = ctx_tot = 0
    for slot in d['context']:
        g, p = gold['context'][slot], pred['context'][slot]
        g_as, p_as = g != dflt['context'][slot], p != dflt['context'][slot]
        if g_as or p_as:
            ctx_tot += 1
            ctx_ok += int(g == p)
        if g_as and p_as and g == p:
            tp += 1
        elif p_as and (not g_as or g != p):
            fp += 1
        if g_as and (not p_as or g != p):
            fn += 1
    ge, pe = set(gold['events']), set(pred['events'])
    tp += len(ge & pe)
    fp += len(pe - ge)
    fn += len(ge - pe)
    exact = (dim_ok == dim_tot) and (ctx_ok == ctx_tot) and (ge == pe)
    prec = tp / (tp + fp) if tp + fp else 1.0
    rec = tp / (tp + fn) if tp + fn else 1.0
    f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0.0
    return {'f1': f1, 'precision': prec, 'recall': rec, 'exact': int(exact),
            'dim_acc': dim_ok / dim_tot if dim_tot else 1.0,
            'ctx_acc': ctx_ok / ctx_tot if ctx_tot else 1.0}
