"""Shared lexicon between the prompt generator (spec -> text) and the
compiler (text -> spec). Every exposure dimension has named levels; every
level has several surface realizations. The FIRST surface form is the one
the generator prefers; the compiler matches any of them (longest match).

This coupling is deliberate and is disclosed in the paper: the corpus is
generated from the same template grammar the parser's lexicon covers, so
raw parsing accuracy is an upper bound; robustness to imperfect front-ends
is assessed separately by error injection.
"""

# dim -> list of (value, [surface forms])
DIM_LEVELS = {
    # ---------------- heights
    'elevation': [
        (0.0,  ['at ground level', 'on the ground floor']),
        (0.25, ['on a second-floor balcony', 'one storey up', 'a low mezzanine']),
        (0.5,  ['on the fifth floor', 'five floors up', 'at mid-rise height']),
        (0.75, ['on the rooftop of an office block', 'ten storeys up']),
        (1.0,  ['at the top of a high tower', 'at a cliff-top height',
                'thirty storeys up']),
    ],
    'edge_proximity': [
        (0.0,  ['well back from the edge', 'far from the edge']),
        (0.33, ['a few steps from the edge', 'some distance from the edge']),
        (0.66, ['close to the edge', 'near the edge']),
        (1.0,  ['right at the edge', 'at the very edge', 'on the brink']),
    ],
    'barrier_openness': [
        (0.0,  ['behind a full glass wall', 'behind a chest-high solid parapet']),
        (0.4,  ['with a sturdy railing', 'with a waist-high railing']),
        (0.7,  ['with only a low guard rail', 'with a flimsy rope barrier']),
        (1.0,  ['with no railing at all', 'with nothing between them and the drop',
                'completely unguarded']),
    ],
    'surface_instability': [
        (0.0, ['on solid concrete', 'on firm footing']),
        (0.5, ['on a slightly springy walkway', 'on creaking boards']),
        (1.0, ['on a swaying platform', 'on a rope bridge that moves underfoot']),
    ],
    'wind_motion': [
        (0.0, ['in still air', 'with no wind']),
        (0.5, ['with a light breeze', 'with a mild breeze']),
        (1.0, ['in gusty wind', 'with strong gusts']),
    ],
    # ---------------- spiders
    'size': [
        (0.1, ['a tiny money spider', 'a very small spider']),
        (0.4, ['a medium-sized house spider', 'an ordinary house spider']),
        (0.7, ['a large huntsman', 'a big hairy spider']),
        (1.0, ['a very large tarantula', 'a fist-sized tarantula']),
    ],
    'proximity': [
        (0.0,  ['across the room in a sealed tank', 'far away behind glass']),
        (0.33, ['a few metres away', 'on the far table']),
        (0.66, ['about an arm\'s length away', 'on the near side of the desk']),
        (1.0,  ['right next to their hand', 'almost touching them']),
    ],
    'count': [
        (0.0, ['a single spider', 'just one spider']),
        (0.4, ['two or three spiders', 'a couple of spiders']),
        (1.0, ['many spiders', 'a dozen spiders']),
    ],
    'movement_speed': [
        (0.0, ['perfectly still', 'motionless']),
        (0.5, ['moving slowly', 'ambling along']),
        (1.0, ['moving quickly', 'darting about']),
    ],
    'unpredictability': [
        (0.0, ['following a steady path', 'moving predictably']),
        (0.5, ['changing direction now and then', 'wandering']),
        (1.0, ['moving erratically', 'with sudden unpredictable turns']),
    ],
    # ---------------- social
    'audience_size': [
        (0.1,  ['to one listener', 'to a single colleague']),
        (0.33, ['to a handful of people', 'to four or five people']),
        (0.66, ['to a room of about twenty', 'to a small lecture group']),
        (1.0,  ['to a packed auditorium', 'to well over a hundred people']),
    ],
    'gaze_proportion': [
        (0.0, ['with the audience mostly looking at their notes',
               'with few people watching directly']),
        (0.5, ['with about half the room watching', 'with many eyes on them']),
        (1.0, ['with every face turned towards them', 'with the whole room staring']),
    ],
    'evaluative_negativity': [
        (0.0, ['with a warm and encouraging audience', 'with friendly nods']),
        (0.4, ['with a neutral, businesslike audience', 'with flat expressions']),
        (0.7, ['with a sceptical audience', 'with some frowning and whispering']),
        (1.0, ['with an openly critical audience', 'with visible disapproval']),
    ],
    'interruption_rate': [
        (0.0, ['with no interruptions', 'uninterrupted']),
        (0.5, ['with occasional interruptions', 'with a question or two thrown in']),
        (1.0, ['with frequent interruptions', 'constantly interrupted']),
    ],
    'task_difficulty': [
        (0.2, ['giving a short prepared introduction', 'reading a prepared text']),
        (0.6, ['presenting familiar material without notes',
               'speaking freely on a familiar topic']),
        (1.0, ['answering hostile questions off the cuff',
               'defending an unfamiliar position unprepared']),
    ],
}

# context slot -> value -> surface forms
CONTEXT_SURFACES = {
    'setting': {
        'indoor_mezzanine': ['an indoor mezzanine', 'a shopping-centre mezzanine'],
        'balcony': ['an apartment balcony', 'a balcony'],
        'office_window': ['a floor-to-ceiling office window', 'an office window ledge'],
        'rooftop': ['a rooftop terrace', 'a flat rooftop'],
        'bridge': ['a pedestrian bridge', 'a footbridge'],
        'cliff_trail': ['a cliffside trail', 'a coastal cliff path'],
        'glass_platform': ['a glass skywalk platform', 'a glass observation deck'],
        'terrarium_room': ['a pet-shop terrarium room', 'a reptile-house corridor'],
        'kitchen': ['a domestic kitchen', 'their own kitchen'],
        'garden_shed': ['a garden shed', 'a cluttered shed'],
        'basement': ['a dim basement', 'a basement storeroom'],
        'bedroom': ['a bedroom', 'their bedroom'],
        'empty_meeting_room': ['an empty meeting room', 'a small empty office'],
        'small_meeting': ['a small team meeting', 'a weekly stand-up'],
        'classroom': ['a classroom', 'a seminar room'],
        'seminar_hall': ['a seminar hall', 'a mid-sized lecture theatre'],
        'auditorium': ['a large auditorium', 'a conference main stage'],
        'wedding_reception': ['a wedding reception', 'a formal reception'],
    },
    'time_of_day': {
        'morning': ['in the morning'], 'midday': ['at midday'],
        'dusk': ['at dusk'],
    },
    'lighting': {
        'bright': ['brightly lit'], 'normal': ['under normal lighting'],
        'dim': ['dimly lit'],
    },
    'familiarity': {
        'friends': ['made up of friends'], 'colleagues': ['made up of colleagues'],
        'strangers': ['made up of strangers'],
    },
    'ambient': {
        'quiet': ['in quiet surroundings'], 'street_noise': ['with street noise below'],
        'crowd_noise': ['with crowd noise below'], 'house_noise': ['with ordinary household sounds'],
        'murmur': ['over a low murmur'], 'phone_rings': ['with phones going off now and then'],
    },
}

EVENT_SURFACES = {
    'gust_of_wind': ['a sudden gust of wind partway through'],
    'object_drop': ['a dropped object clattering down below'],
    'railing_rattle': ['the railing rattling once'],
    'bird_flyby': ['a bird flying past at eye level'],
    'platform_tilt': ['the platform tilting under their feet'],
    'forced_fall': ['a scripted fall from the edge'],
    'web_drop': ['a spider dropping down on a thread'],
    'sudden_dart': ['one sudden dart towards them'],
    'towards_walk': ['the spider walking slowly towards them'],
    'rustle_sound': ['a rustling sound from a corner'],
    'contact_touch': ['the spider crawling onto their hand'],
    'swarm_release': ['a swarm of spiders being released'],
    'pointed_question': ['one pointed question from the back row'],
    'audience_laugh': ['a ripple of laughter at the wrong moment'],
    'walkout': ['several people walking out mid-talk'],
    'phone_interruption': ['a phone ringing mid-sentence'],
    'mic_failure': ['the microphone cutting out briefly'],
    'open_mockery': ['open mockery from the front row'],
}
