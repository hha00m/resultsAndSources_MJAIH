"""Experiment driver with per-condition JSONL checkpointing.

Usage: python3 experiments.py [e1|e2|e3|e4|e5|e6|all]
Each closed-loop condition writes results/<tag>.jsonl (one patient per
line); a condition whose file already holds the expected number of lines
is skipped, so the driver is resumable.
"""

import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, 'results')
os.makedirs(RES, exist_ok=True)

from esdl import (DOMAINS, base_weights, default_contract, ladder_theta,
                  theta_to_spec, validate_and_repair, spec_intensity)
from corpus import generate_corpus, sample_trigger_profile, realize_intake
from compiler import compile_prompt, compile_intake, inject_errors, score_spec
from pcg import instantiate, realized_intensity, diversity_features
from loop import run_patient

N_MAIN = 400
N_E4 = 150
N_E6 = 300
DOMS = list(DOMAINS)
EPS_GRID = [0.0, 0.1, 0.2, 0.3, 0.5]


def _jsonl_path(tag):
    return os.path.join(RES, tag + '.jsonl')


def _count_lines(path):
    if not os.path.exists(path):
        return 0
    with open(path) as f:
        return sum(1 for _ in f)


def run_condition(tag, domain, policy, n, **kw):
    path = _jsonl_path(tag)
    done = _count_lines(path)
    if done >= n:
        return
    t0 = time.time()
    with open(path, 'a') as f:
        for idx in range(done, n):
            rec = run_patient(domain, idx, policy, **kw)
            rec.pop('suds_traj', None) if idx >= 40 else None
            rec.pop('i_traj', None) if idx >= 40 else None
            f.write(json.dumps(rec) + '\n')
            if (idx + 1) % 100 == 0:
                f.flush()
    print(f'[{tag}] {n - done} patients in {time.time() - t0:.0f}s',
          flush=True)


# ------------------------------------------------------------------- E1

def e1_compiler():
    out = {'per_domain': {}, 'eps_sweep': {}, 'unsafe': {}, 'intake': {},
           'fuzz': {}}
    rng = np.random.default_rng(11)
    for dom in DOMS:
        corp = generate_corpus(dom, 650, rng, unsafe_frac=150 / 650)
        scores, unsafe_caught, unsafe_tot = [], 0, 0
        contract = default_contract(dom)
        for rec in corp:
            pred, _ = compile_prompt(rec['prompt'], dom)
            sc = score_spec(pred, rec['gold'], dom)
            if not rec['unsafe']:
                scores.append(sc)
            else:
                unsafe_tot += 1
                safe, rep = validate_and_repair(pred, contract, i_prev=0.2)
                bad_ev = any(e in contract['forbidden'] for e in safe['events'])
                over = spec_intensity(safe) > min(
                    contract['i_cap'], 0.2 + contract['ramp']) + 1e-6
                if rep['violated'] and not bad_ev and not over:
                    unsafe_caught += 1
        agg = {k: float(np.mean([s[k] for s in scores]))
               for k in ('f1', 'precision', 'recall', 'exact', 'dim_acc',
                         'ctx_acc')}
        agg['n_safe'] = len(scores)
        out['per_domain'][dom] = agg
        out['unsafe'][dom] = {'n': unsafe_tot, 'caught': unsafe_caught}
        # eps sweep on parsed safe specs
        sweep = {}
        for eps in EPS_GRID:
            r2 = np.random.default_rng(int(eps * 1000) + 7)
            f1s = []
            for rec in corp:
                if rec['unsafe']:
                    continue
                pred, _ = compile_prompt(rec['prompt'], dom)
                noisy = inject_errors(pred, dom, eps, r2)
                f1s.append(score_spec(noisy, rec['gold'], dom)['f1'])
            sweep[str(eps)] = float(np.mean(f1s))
        out['eps_sweep'][dom] = sweep
        # intake trigger identification
        hit = 0
        cos = []
        n_int = 400
        r3 = np.random.default_rng(31)
        for _ in range(n_int):
            m = sample_trigger_profile(dom, r3)
            txt, trig, nontrig = realize_intake(dom, m, r3)
            w_hat = compile_intake(txt, dom)
            dims = DOMAINS[dom]['dims']
            hit += int(dims[int(np.argmax(w_hat / base_weights(dom)))]
                       == trig)
            cos.append(float(np.dot(w_hat, m)
                             / (np.linalg.norm(w_hat) * np.linalg.norm(m))))
        base_cos = []
        r3b = np.random.default_rng(32)
        for _ in range(n_int):
            m = sample_trigger_profile(dom, r3b)
            wb = base_weights(dom)
            base_cos.append(float(np.dot(wb, m)
                                  / (np.linalg.norm(wb) * np.linalg.norm(m))))
        out['intake'][dom] = {'n': n_int, 'top_trigger_acc': hit / n_int,
                              'cosine_mean': float(np.mean(cos)),
                              'cosine_base': float(np.mean(base_cos))}
    # property fuzz: gate never emits an infeasible spec
    r4 = np.random.default_rng(99)
    n_fuzz, fails = 100_000, 0
    for _ in range(n_fuzz):
        dom = DOMS[r4.integers(3)]
        d = DOMAINS[dom]
        spec = {'domain': dom,
                'theta': {k: float(r4.uniform(-0.3, 1.4)) for k in d['dims']},
                'context': {s: v[r4.integers(len(v))]
                            for s, v in d['context'].items()},
                'events': list(r4.choice(d['events'],
                                         size=r4.integers(0, 3),
                                         replace=False))}
        contract = default_contract(dom, i_cap=float(r4.uniform(0.4, 0.95)),
                                    ramp=float(r4.uniform(0.05, 0.3)))
        i_prev = float(r4.uniform(0.0, 0.8))
        safe, rep = validate_and_repair(spec, contract, i_prev=i_prev)
        cap = min(contract['i_cap'], i_prev + contract['ramp'])
        if (spec_intensity(safe) > cap + 1e-6 or
                any(e in contract['forbidden'] for e in safe['events']) or
                any(not (contract['bounds'][k][0] - 1e-9 <= v <=
                         contract['bounds'][k][1] + 1e-9)
                    for k, v in safe['theta'].items())):
            fails += 1
    out['fuzz'] = {'n': n_fuzz, 'failures': fails}
    with open(os.path.join(RES, 'e1_compiler.json'), 'w') as f:
        json.dump(out, f, indent=1)
    print('E1 done', flush=True)


# ------------------------------------------------------------------- E2

def e2_pcg():
    out = {}
    rng = np.random.default_rng(21)
    for dom in DOMS:
        w = base_weights(dom)
        req, real, tries_all, intra_div = [], [], [], []
        for i_t in np.linspace(0.1, 0.8, 8):
            th = ladder_theta(dom, i_t, w)
            spec = theta_to_spec(dom, th)
            feats = []
            for s in range(50):
                scene, th_r, tries = instantiate(
                    spec, np.random.default_rng(1000 + s))
                tries_all.append(tries)
                i_r = realized_intensity(th_r, [], w)
                req.append(float(i_t))
                real.append(i_r)
                feats.append(diversity_features(scene))
            F = np.array([f[:5] for f in feats])
            D = np.sqrt(((F[:, None] - F[None]) ** 2).sum(-1))
            intra_div.append(float(D[np.triu_indices(len(F), 1)].mean()))
        req, real = np.array(req), np.array(real)
        from scipy.stats import spearmanr
        rho = float(spearmanr(req, real).statistic)
        # inter-prompt diversity over a corpus sample
        corp = generate_corpus(dom, 120, rng)
        feats = []
        for rec in corp:
            pred, _ = compile_prompt(rec['prompt'], dom)
            scene, th_r, _ = instantiate(pred, rng)
            if scene is not None:
                feats.append(diversity_features(scene)[:5])
        F = np.array(feats)
        D = np.sqrt(((F[:, None] - F[None]) ** 2).sum(-1))
        out[dom] = {
            'points_req': req[::2].tolist(),
            'points_real': real[::2].tolist(),
            'rmse': float(np.sqrt(np.mean((req - real) ** 2))),
            'bias': float(np.mean(real - req)),
            'spearman': rho,
            'mean_tries': float(np.mean(tries_all)),
            'fail_rate': float(np.mean(np.array(tries_all) >= 20)),
            'intra_spec_diversity': float(np.mean(intra_div)),
            'inter_prompt_diversity': float(
                D[np.triu_indices(len(F), 1)].mean()),
        }
    with open(os.path.join(RES, 'e2_pcg.json'), 'w') as f:
        json.dump(out, f, indent=1)
    print('E2 done', flush=True)


# ------------------------------------------------------------------- E3-E6

def e3_main():
    for dom in DOMS:
        for pol in ['fixed', 'staircase', 'random', 'pact', 'oracle']:
            run_condition(f'e3_{dom}_{pol}', dom, pol, N_MAIN)


def e4_robustness():
    for dom in DOMS:
        for eps in EPS_GRID:
            for gate in (True, False):
                tag = f'e4_{dom}_pact_eps{int(eps * 100):03d}_' \
                      f'{"on" if gate else "off"}'
                run_condition(tag, dom, 'pact', N_E4, eps=eps, gate_on=gate)


def e5_ablations():
    for dom in DOMS:
        for pol in ['pact_point', 'pact_norisk', 'pact_generic']:
            run_condition(f'e5_{dom}_{pol}', dom, pol, N_MAIN)


def e6_misspec():
    for dom in DOMS:
        for pol in ['staircase', 'pact', 'oracle']:
            run_condition(f'e6_{dom}_{pol}', dom, pol, N_E6, dynamics='pe')


if __name__ == '__main__':
    what = sys.argv[1] if len(sys.argv) > 1 else 'all'
    t0 = time.time()
    if what in ('e1', 'all'):
        e1_compiler()
    if what in ('e2', 'all'):
        e2_pcg()
    if what in ('e3', 'all'):
        e3_main()
    if what in ('e4', 'all'):
        e4_robustness()
    if what in ('e5', 'all'):
        e5_ablations()
    if what in ('e6', 'all'):
        e6_misspec()
    print(f'total {time.time() - t0:.0f}s', flush=True)
