# PACT — Prompt-Guided Procedural Content Generation for Personalized VR Exposure Therapy

Replication package. Everything in the manuscript derives from this code;
no number is hand-entered.

## Layout
- `src/esdl.py`      ESDL language, intensity model, safety contract, projection repair
- `src/lexicon.py`   shared surface lexicon (generator and compiler)
- `src/corpus.py`    synthetic prompt corpus + intake prompts
- `src/compiler.py`  prompt->ESDL reference compiler, intake compiler, error injection, scoring
- `src/pcg.py`       procedural instantiator + realized-dose computation + diversity features
- `src/patient.py`   virtual patient (window + expectancy-violation dynamics, dropout)
- `src/policies.py`  FIXED / STAIR / RAND / PACT (+ablations) / ORACLE
- `src/loop.py`      closed-loop session runner (gate + realize-then-verify)
- `src/experiments.py` E1–E6 drivers, per-patient JSONL checkpointing (resumable)
- `src/analysis.py`  aggregates results/ -> results/summary.json
- `src/validate.py`  14-check validation suite -> results/validation.json
- `src/figures.py`   all manuscript figures
- `build/`           equations, references, content generator, docx renderer

## Reproduce
```bash
python3 src/experiments.py all      # ~1–2 h on 2 CPU cores; resumable
python3 src/analysis.py
python3 src/validate.py             # must print all PASS
./build.sh                          # -> .docx + .pdf
```
Dependencies: numpy, scipy, matplotlib, node with the `docx` package,
LibreOffice for PDF conversion.
