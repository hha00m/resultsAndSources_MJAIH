"""Aggregate experiment JSONL into results/summary.json (the single source
every manuscript number derives from)."""

import json
import os
import sys

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, 'results')
DOMS = ['heights', 'spiders', 'social']
POLS = ['fixed', 'staircase', 'random', 'pact', 'oracle']
ABLS = ['pact_point', 'pact_norisk', 'pact_generic']
EPS_GRID = [0.0, 0.1, 0.2, 0.3, 0.5]
BOOT = 10_000


def load(tag):
    path = os.path.join(RES, tag + '.jsonl')
    with open(path) as f:
        return [json.loads(l) for l in f]


def agg(recs):
    db = np.array([r['delta_b'] for r in recs])
    stc = [r['sessions_to_crit'] for r in recs if r['sessions_to_crit']]
    return {
        'n': len(recs),
        'delta_b_mean': float(db.mean()), 'delta_b_sd': float(db.std(ddof=1)),
        'responder': float(np.mean([r['responder'] for r in recs])),
        'dropout': float(np.mean([r['dropped'] for r in recs])),
        'panics_per_pt': float(np.mean([r['panics'] for r in recs])),
        'window_frac': float(np.sum([r['in_window'] for r in recs])
                             / max(1, np.sum([r['trials'] for r in recs]))),
        'violations_total': int(np.sum([r['violations'] for r in recs])),
        'trials_mean': float(np.mean([r['trials'] for r in recs])),
        'distortion_mean': float(np.mean([r['distortion'] for r in recs])),
        'sessions_to_crit_median': float(np.median(stc)) if stc else None,
        'crit_reached': float(len(stc) / len(recs)),
    }


def paired(recs_a, recs_b, field='delta_b', boot=BOOT, seed=7):
    """Paired difference a-b by patient idx, with bootstrap CI and dz."""
    da = {r['idx']: r[field] for r in recs_a}
    db_ = {r['idx']: r[field] for r in recs_b}
    common = sorted(set(da) & set(db_))
    d = np.array([float(da[i]) - float(db_[i]) for i in common])
    rng = np.random.default_rng(seed)
    bs = np.array([d[rng.integers(len(d), size=len(d))].mean()
                   for _ in range(boot)])
    sd = d.std(ddof=1)
    return {'n': len(d), 'mean': float(d.mean()),
            'ci_lo': float(np.percentile(bs, 2.5)),
            'ci_hi': float(np.percentile(bs, 97.5)),
            'dz': float(d.mean() / sd) if sd > 0 else 0.0,
            'p_boot': float(2 * min((bs <= 0).mean(), (bs >= 0).mean()))}


def main():
    summary = {}
    with open(os.path.join(RES, 'e1_compiler.json')) as f:
        summary['e1'] = json.load(f)
    with open(os.path.join(RES, 'e2_pcg.json')) as f:
        e2 = json.load(f)
    for dom in e2:
        e2[dom].pop('points_req', None) and None
    summary['e2'] = e2

    e3 = {}
    cache = {}
    for dom in DOMS:
        e3[dom] = {}
        for pol in POLS:
            recs = load(f'e3_{dom}_{pol}')
            cache[(dom, pol)] = recs
            e3[dom][pol] = agg(recs)
        e3[dom]['paired_vs_pact'] = {}
        for pol in ['fixed', 'staircase', 'random', 'oracle']:
            for f_ in ['delta_b', 'panics', 'dropped']:
                e3[dom]['paired_vs_pact'][f'{pol}_{f_}'] = paired(
                    cache[(dom, 'pact')], cache[(dom, pol)], f_)
    # pooled paired tests across domains
    pooled = {}
    for pol in ['fixed', 'staircase', 'random', 'oracle']:
        allp, allb = [], []
        for dom in DOMS:
            for r in cache[(dom, 'pact')]:
                allp.append({'idx': f"{dom}_{r['idx']}",
                             'delta_b': r['delta_b'], 'panics': r['panics'],
                             'dropped': r['dropped']})
            for r in cache[(dom, pol)]:
                allb.append({'idx': f"{dom}_{r['idx']}",
                             'delta_b': r['delta_b'], 'panics': r['panics'],
                             'dropped': r['dropped']})
        pooled[pol] = {f_: paired(allp, allb, f_)
                       for f_ in ['delta_b', 'panics', 'dropped']}
    e3['pooled_paired_vs_pact'] = pooled
    summary['e3'] = e3

    e4 = {}
    for dom in DOMS:
        e4[dom] = {}
        for eps in EPS_GRID:
            for gate in ('on', 'off'):
                tag = f'e4_{dom}_pact_eps{int(eps * 100):03d}_{gate}'
                e4[dom][f'{eps}_{gate}'] = agg(load(tag))
    summary['e4'] = e4

    e5 = {}
    for dom in DOMS:
        e5[dom] = {}
        for pol in ABLS:
            recs = load(f'e5_{dom}_{pol}')
            e5[dom][pol] = agg(recs)
            e5[dom][pol]['paired_vs_pact'] = paired(
                cache[(dom, 'pact')], recs)
    summary['e5'] = e5

    e6 = {}
    for dom in DOMS:
        e6[dom] = {}
        for pol in ['staircase', 'pact', 'oracle', 'pact_norisk']:
            e6[dom][pol] = agg(load(f'e6_{dom}_{pol}'))
    summary['e6'] = e6

    # trajectory means for figures (heights, first 40 patients with traj)
    traj = {}
    for pol in ['fixed', 'staircase', 'pact']:
        recs = [r for r in cache[('heights', pol)] if 'suds_traj' in r]
        L = 64
        S = np.full((len(recs), L), np.nan)
        I = np.full((len(recs), L), np.nan)
        for k, r in enumerate(recs):
            s = r['suds_traj'][:L]
            S[k, :len(s)] = s
            i = r['i_traj'][:L]
            I[k, :len(i)] = i
        traj[pol] = {
            'suds_mean': np.nanmean(S, 0).round(2).tolist(),
            'i_mean': np.nanmean(I, 0).round(3).tolist(),
            'n': len(recs)}
    summary['traj_heights'] = traj

    with open(os.path.join(RES, 'summary.json'), 'w') as f:
        json.dump(summary, f, indent=1)
    print('summary.json written')


if __name__ == '__main__':
    main()
