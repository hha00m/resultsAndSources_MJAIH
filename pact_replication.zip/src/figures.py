"""Generate all manuscript figures from results/ into figures/.
Grayscale-safe: series differ by marker + linestyle + hatch, not color alone.
"""

import json
import os
import sys

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, 'results')
FIG = os.path.join(ROOT, 'figures')
os.makedirs(FIG, exist_ok=True)

plt.rcParams.update({
    'font.family': 'serif', 'font.size': 9, 'axes.linewidth': 0.8,
    'figure.dpi': 300, 'savefig.bbox': 'tight', 'savefig.dpi': 300,
    'axes.spines.top': False, 'axes.spines.right': False,
    'legend.frameon': False,
})

GRAY = ['#1a1a1a', '#4d4d4d', '#808080', '#b3b3b3', '#d9d9d9']
POLS = ['fixed', 'staircase', 'random', 'pact', 'oracle']
PNAMES = {'fixed': 'FIXED', 'staircase': 'STAIR', 'random': 'RAND',
          'pact': 'PACT', 'oracle': 'ORACLE', 'pact_point': 'PACT-PT',
          'pact_norisk': 'PACT-NR', 'pact_generic': 'PACT-GEN'}
DOMS = ['heights', 'spiders', 'social']
DNAMES = {'heights': 'Heights', 'spiders': 'Spiders', 'social': 'Social'}


def load(tag):
    with open(os.path.join(RES, tag + '.jsonl')) as f:
        return [json.loads(l) for l in f]


def boot_ci(x, n=5000, seed=3):
    x = np.asarray(x, float)
    rng = np.random.default_rng(seed)
    bs = np.array([x[rng.integers(len(x), size=len(x))].mean()
                   for _ in range(n)])
    return x.mean(), np.percentile(bs, 2.5), np.percentile(bs, 97.5)


# ------------------------------------------------------------- F1 pipeline

def fig_architecture():
    fig, ax = plt.subplots(figsize=(7.2, 3.2))
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 50)
    ax.axis('off')

    def box(x, y, w, h, label, fs=7.6, fc='white', lw=1.0,
            style='round,pad=0.25'):
        b = FancyBboxPatch((x, y), w, h, boxstyle=style, fc=fc,
                           ec='#1a1a1a', lw=lw)
        ax.add_patch(b)
        ax.text(x + w / 2, y + h / 2, label, ha='center', va='center',
                fontsize=fs)
        return b

    def arrow(x1, y1, x2, y2, label=None, lx=None, ly=None, fs=6.8):
        a = FancyArrowPatch((x1, y1), (x2, y2), arrowstyle='-|>',
                            mutation_scale=8, lw=0.9, color='#1a1a1a')
        ax.add_patch(a)
        if label:
            ax.text(lx if lx is not None else (x1 + x2) / 2,
                    ly if ly is not None else (y1 + y2) / 2 + 2.2,
                    label, ha='center', fontsize=fs, style='italic')

    # row 1: authoring path (y 34..46)
    box(1, 34, 14, 12, 'Therapist /\npatient\nprompt')
    box(20, 34, 15, 12, 'Prompt-to-\nESDL\ncompiler', fc='#f0f0f0')
    box(40, 34, 13, 12, 'ESDL\nscene spec.')
    box(58, 34, 14, 12, 'Safety gate\n(contract $\\mathcal{C}$)',
        fc='#f0f0f0')
    box(77, 34, 12, 12, 'PCG\ninstantiator', fc='#f0f0f0')
    box(93, 34, 6.5, 12, 'VR\nscene')
    arrow(15, 40, 20, 40)
    arrow(35, 40, 40, 40)
    arrow(53, 40, 58, 40)
    arrow(72, 40, 77, 40, 'repair /\nverify', lx=74.5, ly=47.0)
    arrow(89, 40, 93, 40)

    # row 2: adaptation loop (y 6..18)
    box(1, 6, 14, 12, 'Intake\nprompt\n(triggers)')
    box(27, 6, 17, 12, 'Particle filter\nover patient\nparameters',
        fc='#f0f0f0')
    box(52, 6, 18, 12, 'Risk-constrained\ndose selection\n(Alg. 2)',
        fc='#f0f0f0')
    box(85, 6, 14.5, 12, 'Virtual patient\n(SUDS $s_t$)')
    arrow(96.2, 34, 93.5, 18, 'exposure', lx=98.0, ly=25)
    # SUDS feedback routed under the row
    ax.plot([92, 92], [6, 1.5], color='#1a1a1a', lw=0.9)
    ax.plot([92, 35.5], [1.5, 1.5], color='#1a1a1a', lw=0.9)
    arrow(35.5, 1.5, 35.5, 6)
    ax.text(64, 2.6, 'SUDS $s_t$, panic', ha='center', fontsize=6.8,
            style='italic')
    arrow(44, 12, 52, 12, 'posterior', lx=48, ly=14.6)
    arrow(62, 18, 64, 34, 'next dose $i_{t+1}$', lx=55.5, ly=25.5)
    arrow(15, 12, 27, 12, 'trigger profile $\\hat{w}$', lx=21, ly=15.2)
    fig.savefig(os.path.join(FIG, 'fig1_architecture.png'))
    plt.close(fig)


# ------------------------------------------- F2 patient model illustration

def fig_patient_model():
    from patient import PatientSim, learning_gain, sigmoid
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.6))
    s = np.linspace(0, 100, 400)
    axes[0].plot(s, learning_gain(s), color=GRAY[0], lw=1.4,
                 label='window kernel $g(s)$')
    # pe learning vs suds for an example patient (a=8, b=0.45, b_hat=0.30)
    a, b, bh = 8.0, 0.45, 0.30
    i_grid = np.linspace(0, 1, 400)
    s_hat = 100 * sigmoid(a * (i_grid - b))
    e_hat = 100 * sigmoid(a * (i_grid - bh))
    pe = np.maximum(0, e_hat - s_hat) / 40.0
    axes[0].plot(s_hat, pe / pe.max(), color=GRAY[2], lw=1.4, ls='--',
                 label='expectancy-violation\n(normalized, example)')
    axes[0].axvspan(30, 70, color='#eeeeee', zorder=0)
    axes[0].set_xlabel('SUDS $s$')
    axes[0].set_ylabel('relative learning rate')
    axes[0].legend(fontsize=7.2, loc='upper left')
    axes[0].set_title('(a)', fontsize=9, loc='left')

    # (b) tolerance trajectories under three constant nominal doses
    params = dict(domain='heights', dynamics='window', b0=0.30, a=8.0,
                  s_pan=84.0, eta_h=0.03, eta_s=0.18, rho=0.25,
                  m=[0.42, 0.28, 0.34, 0.20, 0.12],
                  d0=-3.0, d_pan=1.5, d_dist=1.8, d_fut=1.4, d_prog=2.0,
                  d_tot=1.5)
    styles = [('-', GRAY[0]), ('--', GRAY[1]), (':', GRAY[2])]
    for (dose, lab), (ls, c) in zip(
            [(0.20, 'low dose (0.20)'), (0.42, 'moderate dose (0.42)'),
             (0.75, 'excessive dose (0.75)')], styles):
        sim = PatientSim(params, np.random.default_rng(5))
        bs = [sim.b]
        for t in range(8):
            b_start = sim.b
            slist = []
            for j in range(8):
                s_, pan = sim.respond(dose)
                slist.append(s_)
                if pan:
                    break
            sim.p['d0'] = -99          # disable dropout for illustration
            sim.end_session(slist, 0, b_start)
            bs.append(sim.b)
        axes[1].plot(range(9), bs, ls, color=c, lw=1.4, marker='o', ms=3,
                     label=lab)
    axes[1].set_xlabel('session')
    axes[1].set_ylabel('fear tolerance $b_t$')
    axes[1].legend(fontsize=7.2, loc='upper left')
    axes[1].set_title('(b)', fontsize=9, loc='left')
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, 'fig2_patient_model.png'))
    plt.close(fig)


# ------------------------------------------------------ F3 calibration

def fig_calibration():
    with open(os.path.join(RES, 'e2_pcg.json')) as f:
        e2 = json.load(f)
    fig, ax = plt.subplots(figsize=(3.5, 3.2))
    markers = ['o', 's', '^']
    for dom, mk, c in zip(DOMS, markers, GRAY[:3]):
        req = np.array(e2[dom]['points_req'])
        real = np.array(e2[dom]['points_real'])
        jit = np.random.default_rng(1).normal(0, 0.004, len(req))
        ax.plot(req + jit, real, mk, ms=2.6, mfc='none', mec=c, mew=0.7,
                label=f"{DNAMES[dom]} (RMSE {e2[dom]['rmse']:.3f})")
    ax.plot([0, 0.9], [0, 0.9], '-', color='#999999', lw=0.8, zorder=0)
    ax.set_xlabel('requested intensity $I$')
    ax.set_ylabel('realized intensity $\\hat{I}$')
    ax.legend(fontsize=7.2, loc='upper left')
    fig.savefig(os.path.join(FIG, 'fig3_calibration.png'))
    plt.close(fig)


# ------------------------------------------------------ F4 main results

def fig_main():
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.8))
    width = 0.15
    x = np.arange(len(DOMS))
    hatches = ['', '///', 'xxx', '...', '\\\\\\']
    for pi, pol in enumerate(POLS):
        means, los, his, drops = [], [], [], []
        for dom in DOMS:
            recs = load(f'e3_{dom}_{pol}')
            m, lo, hi = boot_ci([r['delta_b'] for r in recs])
            means.append(m)
            los.append(m - lo)
            his.append(hi - m)
            drops.append(100 * np.mean([r['dropped'] for r in recs]))
        pos = x + (pi - 2) * width
        axes[0].bar(pos, means, width * 0.92, yerr=[los, his], capsize=1.5,
                    error_kw={'lw': 0.7}, color='white', edgecolor=GRAY[0],
                    lw=0.8, hatch=hatches[pi], label=PNAMES[pol])
        axes[1].bar(pos, drops, width * 0.92, color='white',
                    edgecolor=GRAY[0], lw=0.8, hatch=hatches[pi])
    axes[0].set_xticks(x)
    axes[0].set_xticklabels([DNAMES[d] for d in DOMS])
    axes[0].set_ylabel('fear reduction $\\Delta b$ (ITT)')
    axes[0].set_ylim(0, 0.52)
    axes[0].legend(fontsize=6.6, ncol=5, loc='upper center',
                   bbox_to_anchor=(0.5, 1.02), columnspacing=0.8,
                   handlelength=1.2)
    axes[0].set_title('(a)', fontsize=9, loc='left', pad=10)
    axes[1].set_xticks(x)
    axes[1].set_xticklabels([DNAMES[d] for d in DOMS])
    axes[1].set_ylabel('dropout (%)')
    axes[1].set_title('(b)', fontsize=9, loc='left')
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, 'fig4_main.png'))
    plt.close(fig)


# ------------------------------------------------------ F5 trajectories

def fig_traj():
    with open(os.path.join(RES, 'summary.json')) as f:
        traj = json.load(f)['traj_heights']
    fig, axes = plt.subplots(2, 1, figsize=(7.0, 3.4), sharex=True)
    styles = {'fixed': ('-', GRAY[2], 'o'), 'staircase': ('--', GRAY[1], 's'),
              'pact': ('-', GRAY[0], '^')}
    for pol, (ls, c, mk) in styles.items():
        s = np.array(traj[pol]['suds_mean'], float)
        i = np.array(traj[pol]['i_mean'], float)
        t = np.arange(1, len(s) + 1)
        axes[0].plot(t, s, ls, color=c, lw=1.2, marker=mk, ms=2.4,
                     markevery=4, label=PNAMES[pol])
        axes[1].plot(t, i, ls, color=c, lw=1.2, marker=mk, ms=2.4,
                     markevery=4)
    axes[0].axhspan(30, 70, color='#eeeeee', zorder=0)
    for k in range(1, 8):
        for ax in axes:
            ax.axvline(8 * k + 0.5, color='#cccccc', lw=0.5, zorder=0)
    axes[0].set_ylim(5, 78)
    axes[0].set_ylabel('mean SUDS')
    axes[0].legend(fontsize=7.2, ncol=3, loc='upper right')
    axes[1].set_ylabel('mean nominal dose $I$')
    axes[1].set_xlabel('trial (sessions separated by grid lines)')
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, 'fig5_traj.png'))
    plt.close(fig)


# ------------------------------------------------------ F6 robustness

def fig_robustness():
    eps_grid = [0.0, 0.1, 0.2, 0.3, 0.5]
    fig, axes = plt.subplots(1, 3, figsize=(7.0, 2.4))
    for gate, ls, mk, c in [('on', '-', 'o', GRAY[0]),
                            ('off', '--', 's', GRAY[2])]:
        db, dr, vi = [], [], []
        for eps in eps_grid:
            recs = []
            for dom in DOMS:
                recs += load(f'e4_{dom}_pact_eps{int(eps*100):03d}_{gate}')
            db.append(boot_ci([r['delta_b'] for r in recs]))
            dr.append(100 * np.mean([r['dropped'] for r in recs]))
            vi.append(np.mean([r['violations'] for r in recs]))
        m = [d[0] for d in db]
        lo = [d[0] - d[1] for d in db]
        hi = [d[2] - d[0] for d in db]
        axes[0].errorbar(eps_grid, m, yerr=[lo, hi], fmt=ls, marker=mk,
                         ms=3.5, color=c, lw=1.2, capsize=2,
                         label=f'gate {gate}')
        axes[1].plot(eps_grid, dr, ls, marker=mk, ms=3.5, color=c, lw=1.2)
        axes[2].plot(eps_grid, vi, ls, marker=mk, ms=3.5, color=c, lw=1.2)
    axes[0].set_ylabel('fear reduction $\\Delta b$')
    axes[0].legend(fontsize=7.2)
    axes[1].set_ylabel('dropout (%)')
    axes[2].set_ylabel('violations / patient')
    for ax, t in zip(axes, ['(a)', '(b)', '(c)']):
        ax.set_xlabel('front-end slot error rate $\\varepsilon$')
        ax.set_title(t, fontsize=9, loc='left')
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, 'fig6_robustness.png'))
    plt.close(fig)


# ------------------------------------------------------ F7 ablations

def fig_ablation():
    fig, ax = plt.subplots(figsize=(3.5, 2.8))
    variants = ['pact', 'pact_point', 'pact_norisk', 'pact_generic']
    hatches = ['', '///', 'xxx', '...']
    width = 0.2
    x = np.arange(len(DOMS))
    for vi_, var in enumerate(variants):
        means, los, his = [], [], []
        for dom in DOMS:
            tag = f'e3_{dom}_pact' if var == 'pact' else f'e5_{dom}_{var}'
            recs = load(tag)
            m, lo, hi = boot_ci([r['delta_b'] for r in recs])
            means.append(m)
            los.append(m - lo)
            his.append(hi - m)
        ax.bar(x + (vi_ - 1.5) * width, means, width * 0.9,
               yerr=[los, his], capsize=1.5, error_kw={'lw': 0.7},
               color='white', edgecolor=GRAY[0], lw=0.8, hatch=hatches[vi_],
               label=PNAMES[var])
    ax.set_xticks(x)
    ax.set_xticklabels([DNAMES[d] for d in DOMS])
    ax.set_ylabel('fear reduction $\\Delta b$')
    ax.legend(fontsize=6.6, ncol=2, loc='lower right')
    fig.savefig(os.path.join(FIG, 'fig7_ablation.png'))
    plt.close(fig)


# ------------------------------------------------------ F8 misspecification

def fig_misspec():
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.6))
    pols = ['staircase', 'pact', 'oracle']
    width = 0.26
    x = np.arange(len(pols))
    for di, (dyn, hatch) in enumerate([('window', ''), ('pe', '///')]):
        means, los, his, drops = [], [], [], []
        for pol in pols:
            recs = []
            for dom in DOMS:
                tag = f'e3_{dom}_{pol}' if dyn == 'window' \
                    else f'e6_{dom}_{pol}'
                recs += load(tag)
            m, lo, hi = boot_ci([r['delta_b'] for r in recs])
            means.append(m)
            los.append(m - lo)
            his.append(hi - m)
            drops.append(100 * np.mean([r['dropped'] for r in recs]))
        pos = x + (di - 0.5) * width
        lab = 'window (assumed)' if dyn == 'window' \
            else 'expectancy-violation (misspecified)'
        axes[0].bar(pos, means, width * 0.9, yerr=[los, his], capsize=1.5,
                    error_kw={'lw': 0.7}, color='white', edgecolor=GRAY[0],
                    lw=0.8, hatch=hatch, label=lab)
        axes[1].bar(pos, drops, width * 0.9, color='white',
                    edgecolor=GRAY[0], lw=0.8, hatch=hatch)
    for ax, ylab, t in [(axes[0], 'fear reduction $\\Delta b$', '(a)'),
                        (axes[1], 'dropout (%)', '(b)')]:
        ax.set_xticks(x)
        ax.set_xticklabels([PNAMES[p] for p in pols])
        ax.set_ylabel(ylab)
        ax.set_title(t, fontsize=9, loc='left')
    axes[0].set_ylim(0, 0.54)
    axes[0].legend(fontsize=6.8, loc='upper left')
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, 'fig8_misspec.png'))
    plt.close(fig)


if __name__ == '__main__':
    which = sys.argv[1] if len(sys.argv) > 1 else 'all'
    if which in ('arch', 'all'):
        fig_architecture()
        fig_patient_model()
        fig_calibration()
    if which == 'all':
        fig_main()
        fig_traj()
        fig_robustness()
        fig_ablation()
        fig_misspec()
    print('figures done:', sorted(os.listdir(FIG)))
