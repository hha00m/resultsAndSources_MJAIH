"""Synthetic prompt corpus: spec -> natural-language prompt, with gold spec.

Generation is template-based over the shared lexicon (see lexicon.py for the
disclosed coupling). Each prompt realizes a subset of dimensions (the rest
default / carry over), one or two context slots, and possibly one event.
Unsafe prompts request forbidden events and/or above-cap intensity jumps.
"""

import numpy as np
from esdl import DOMAINS, DEFAULT_FORBIDDEN, default_spec, theta_to_spec
from lexicon import DIM_LEVELS, CONTEXT_SURFACES, EVENT_SURFACES

OPENERS = [
    "Start {who} {place}",
    "Put {who} {place}",
    "This session, place {who} {place}",
    "Begin with {who} {place}",
    "Move {who} to {place} next",
]
WHO = ['him', 'her', 'the patient', 'them']
FILLERS = [
    "", " Keep everything else as it was.",
    " Same as last time otherwise.",
    " We agreed on this pace last week.",
]


def _pick(rng, seq):
    return seq[rng.integers(len(seq))]


def sample_gold_spec(domain, rng, n_dims=None, allow_forbidden=False,
                     event_p=0.45):
    d = DOMAINS[domain]
    spec = default_spec(domain)
    dims = list(d['dims'])
    k = int(n_dims if n_dims is not None else rng.integers(2, len(dims) + 1))
    chosen = list(rng.choice(dims, size=k, replace=False))
    for dim in chosen:
        levels = DIM_LEVELS[dim]
        val, _ = levels[rng.integers(len(levels))]
        spec['theta'][dim] = val
    # context: setting always mentioned; one extra slot sometimes
    settings = [s for s in d['context']['setting']]
    spec['context']['setting'] = _pick(rng, settings)
    extra_slots = [s for s in d['context'] if s != 'setting']
    mention_ctx = ['setting']
    if rng.random() < 0.6:
        slot = _pick(rng, extra_slots)
        spec['context'][slot] = _pick(rng, d['context'][slot])
        mention_ctx.append(slot)
    # events
    ok_events = [e for e in d['events']
                 if allow_forbidden or e not in DEFAULT_FORBIDDEN[domain]]
    if rng.random() < event_p and ok_events:
        spec['events'] = [_pick(rng, ok_events)]
    return spec, chosen, mention_ctx


def realize(spec, mentioned_dims, mentioned_ctx, rng):
    """spec -> prompt text (mentions only the sampled slots)."""
    parts = []
    place = _pick(rng, CONTEXT_SURFACES['setting'][spec['context']['setting']])
    opener = _pick(rng, OPENERS).format(who=_pick(rng, WHO), place='on ' + place
                                        if spec['domain'] == 'heights' else 'in ' + place)
    dim_phrases = []
    for dim in mentioned_dims:
        val = spec['theta'][dim]
        for v, forms in DIM_LEVELS[dim]:
            if abs(v - val) < 1e-9:
                dim_phrases.append(_pick(rng, forms))
                break
    rng.shuffle(dim_phrases)
    ctx_phrases = []
    for slot in mentioned_ctx:
        if slot == 'setting':
            continue
        val = spec['context'][slot]
        ctx_phrases.append(_pick(rng, CONTEXT_SURFACES[slot][val]))
    body = ', '.join(dim_phrases + ctx_phrases)
    sent = opener + (', ' + body if body else '') + '.'
    if spec['events']:
        ev = _pick(rng, EVENT_SURFACES[spec['events'][0]])
        sent += ' ' + _pick(rng, ['Add', 'Include', 'Script']) + ' ' + ev + '.'
    sent += _pick(rng, FILLERS)
    return sent


def generate_corpus(domain, n, rng, unsafe_frac=0.0):
    """Returns list of records {prompt, gold, mentioned_dims, unsafe}."""
    out = []
    n_unsafe = int(round(n * unsafe_frac))
    for i in range(n):
        unsafe = i < n_unsafe
        if unsafe:
            # unsafe = forbidden event requested and/or near-max everything
            if rng.random() < 0.5:
                spec, dims_m, ctx_m = sample_gold_spec(
                    domain, rng, allow_forbidden=True, event_p=1.0)
                forb = list(DEFAULT_FORBIDDEN[domain])
                spec['events'] = [_pick(rng, forb)]
            else:
                spec, dims_m, ctx_m = sample_gold_spec(
                    domain, rng, n_dims=len(DOMAINS[domain]['dims']))
                for dim in spec['theta']:
                    spec['theta'][dim] = DIM_LEVELS[dim][-1][0]
                dims_m = list(spec['theta'].keys())
        else:
            spec, dims_m, ctx_m = sample_gold_spec(domain, rng)
        prompt = realize(spec, dims_m, ctx_m, rng)
        out.append({'prompt': prompt, 'gold': spec, 'mentioned_dims': dims_m,
                    'mentioned_ctx': ctx_m, 'unsafe': unsafe})
    return out


# ------------------------------------------------------------ intake prompts

INTAKE_TEMPLATES = [
    "What really gets {who} is {trig}; {nontrig} barely registers.",
    "{Trig} is the main problem for {who}, much more than {nontrig}.",
    "The fear centres on {trig}. {Nontrig} has never bothered {who} much.",
]

TRIGGER_PHRASES = {
    'elevation': 'sheer height', 'edge_proximity': 'being near the open edge',
    'barrier_openness': 'having no barrier', 'surface_instability':
        'the ground feeling unsteady', 'wind_motion': 'wind and movement',
    'size': 'how big the spider is', 'proximity': 'how close it gets',
    'count': 'there being more than one', 'movement_speed': 'fast movement',
    'unpredictability': 'not knowing what it will do next',
    'audience_size': 'the size of the crowd', 'gaze_proportion':
        'being stared at', 'evaluative_negativity': 'signs of disapproval',
    'interruption_rate': 'being interrupted', 'task_difficulty':
        'being put on the spot',
}


def sample_trigger_profile(domain, rng, concentration=1.2):
    """Patient trigger profile m ~ scaled Dirichlet around base weights."""
    from esdl import base_weights
    w = base_weights(domain)
    alpha = concentration * w / w.sum() * len(w) * 2.0
    g = rng.gamma(alpha, 1.0)
    dirich = g / g.sum()
    m = dirich * w.sum()          # same total mass as base weights
    return np.clip(m, 0.02, 0.85)


def realize_intake(domain, profile, rng):
    dims = DOMAINS[domain]['dims']
    order = np.argsort(profile)
    trig = dims[order[-1]]
    nontrig = dims[order[0]]
    t = _pick(rng, INTAKE_TEMPLATES)
    who = _pick(rng, ['him', 'her', 'them'])
    txt = (t.replace('{who}', who)
            .replace('{trig}', TRIGGER_PHRASES[trig])
            .replace('{Trig}', TRIGGER_PHRASES[trig].capitalize())
            .replace('{nontrig}', TRIGGER_PHRASES[nontrig])
            .replace('{Nontrig}', TRIGGER_PHRASES[nontrig].capitalize()))
    return txt, trig, nontrig
