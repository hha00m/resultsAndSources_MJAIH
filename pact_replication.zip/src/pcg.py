"""Procedural instantiation of ESDL specs into concrete scene descriptions.

The instantiator maps a validated spec to a concrete, renderable scene
record (geometry, agents, event schedule, audio) by seeded constraint
sampling. Continuous scene attributes are quantized to plausible asset
granularity, so the realized exposure vector differs slightly from the
requested one; realized intensity is recomputed from the realized vector.
"""

import numpy as np
from esdl import DOMAINS, base_weights, intensity, spec_theta_vec

# per-event added salience (aversive scripted events raise effective dose)
EVENT_SALIENCE = {
    'gust_of_wind': 0.10, 'object_drop': 0.08, 'railing_rattle': 0.07,
    'bird_flyby': 0.05, 'platform_tilt': 0.30, 'forced_fall': 0.50,
    'web_drop': 0.12, 'sudden_dart': 0.15, 'towards_walk': 0.10,
    'rustle_sound': 0.05, 'contact_touch': 0.45, 'swarm_release': 0.40,
    'pointed_question': 0.10, 'audience_laugh': 0.12, 'walkout': 0.30,
    'phone_interruption': 0.05, 'mic_failure': 0.08, 'open_mockery': 0.45,
}


def _quant(x, step, rng, jitter):
    """Quantize to asset granularity with placement jitter, clipped to [0,1]."""
    q = np.round(x / step) * step
    return float(np.clip(q + rng.normal(0, jitter), 0.0, 1.0))


def instantiate(spec, rng, max_tries=20):
    """Returns (scene, realized_theta, tries). Scene is a dict of concrete
    attributes; realized_theta is the back-mapped exposure vector."""
    dom = spec['domain']
    dims = DOMAINS[dom]['dims']
    th = spec_theta_vec(spec)
    for attempt in range(1, max_tries + 1):
        r = {}
        if dom == 'heights':
            elev_m = _quant(th[0], 0.05, rng, 0.01) * 50.0        # 2.5 m steps
            r['elevation_m'] = round(elev_m, 1)
            r['dist_to_edge_m'] = round((1 - _quant(th[1], 1 / 12, rng, 0.015)) * 4.0, 2)
            r['railing_coverage'] = round(1 - _quant(th[2], 0.1, rng, 0.01), 2)
            r['platform_sway_cm'] = round(_quant(th[3], 0.25, rng, 0.01) * 12.0, 1)
            r['wind_gusts_per_min'] = round(_quant(th[4], 0.25, rng, 0.01) * 6.0, 1)
            realized = np.array([r['elevation_m'] / 50.0,
                                 1 - r['dist_to_edge_m'] / 4.0,
                                 1 - r['railing_coverage'],
                                 r['platform_sway_cm'] / 12.0,
                                 r['wind_gusts_per_min'] / 6.0])
            ok = r['dist_to_edge_m'] >= 0.0
        elif dom == 'spiders':
            n_sp = int(1 + round(_quant(th[2], 1 / 11, rng, 0.01) * 11))
            room = 6.0
            d_near = (1 - _quant(th[1], 1 / 10, rng, 0.015)) * 5.0 + 0.05
            pos = rng.uniform(0.2, room - 0.2, size=(n_sp, 2))
            # nearest spider pinned to requested distance from the user at (0,0)
            ang = rng.uniform(0, 2 * np.pi)
            pos[0] = [d_near * np.cos(ang) + room / 2, d_near * np.sin(ang) + room / 2]
            ok = True
            if n_sp > 1:
                dmat = np.sqrt(((pos[:, None] - pos[None]) ** 2).sum(-1))
                np.fill_diagonal(dmat, 9.9)
                ok = dmat.min() > 0.25          # placement constraint
            r['n_spiders'] = n_sp
            r['body_size_cm'] = round(0.5 + _quant(th[0], 0.1, rng, 0.01) * 11.5, 1)
            r['nearest_dist_m'] = round(d_near, 2)
            r['speed_cm_s'] = round(_quant(th[3], 0.2, rng, 0.01) * 8.0, 1)
            r['turn_entropy'] = round(_quant(th[4], 0.2, rng, 0.01), 2)
            r['positions'] = pos.round(2).tolist()
            realized = np.array([(r['body_size_cm'] - 0.5) / 11.5,
                                 1 - (r['nearest_dist_m'] - 0.05) / 5.0,
                                 (r['n_spiders'] - 1) / 11.0,
                                 r['speed_cm_s'] / 8.0,
                                 r['turn_entropy']])
        else:  # social
            n_aud = int(round(1 + _quant(th[0], 1 / 24, rng, 0.01) * 119))
            r['audience_n'] = n_aud
            r['gaze_frac'] = round(_quant(th[1], 0.1, rng, 0.02), 2)
            r['neg_valence'] = round(_quant(th[2], 0.1, rng, 0.02), 2)
            rate = _quant(th[3], 0.25, rng, 0.01) * 4.0
            n_int = rng.poisson(rate * 5.0 / 60.0 * 60)  # per ~5-min block... rate/min * 5
            r['interruptions'] = int(min(n_int, 20))
            r['interrupt_rate_pm'] = round(rate, 2)
            r['task_level'] = round(_quant(th[4], 0.2, rng, 0.01), 2)
            r['seats'] = int(np.ceil(n_aud / 0.8))
            realized = np.array([(n_aud - 1) / 119.0, r['gaze_frac'],
                                 r['neg_valence'], rate / 4.0, r['task_level']])
            ok = True
        if ok:
            realized = np.clip(realized, 0.0, 1.0)
            scene = {'domain': dom, 'attrs': r, 'context': dict(spec['context']),
                     'events': list(spec['events'])}
            return scene, realized, attempt
    return None, None, max_tries


def realized_intensity(realized_theta, events, weights):
    """Effective realized dose including event salience (noisy-OR)."""
    i0 = intensity(realized_theta, weights)
    for e in events:
        i0 = 1 - (1 - i0) * (1 - EVENT_SALIENCE.get(e, 0.05))
    return float(min(i0, 0.995))


def diversity_features(scene):
    """Fixed-length feature vector for scene diversity measurement."""
    a = scene['attrs']
    dom = scene['domain']
    if dom == 'heights':
        v = [a['elevation_m'] / 50, a['dist_to_edge_m'] / 4,
             a['railing_coverage'], a['platform_sway_cm'] / 12,
             a['wind_gusts_per_min'] / 6]
    elif dom == 'spiders':
        pos = np.array(a['positions'])
        v = [(a['body_size_cm'] - .5) / 11.5, a['nearest_dist_m'] / 5,
             a['n_spiders'] / 12, a['speed_cm_s'] / 8, a['turn_entropy'],
             float(pos[:, 0].mean() / 6), float(pos[:, 1].mean() / 6)]
    else:
        v = [a['audience_n'] / 120, a['gaze_frac'], a['neg_valence'],
             a['interrupt_rate_pm'] / 4, a['task_level'],
             a['interruptions'] / 20]
    ctx_slots = sorted(scene['context'])
    v += [hash(scene['context'][s]) % 97 / 96.0 for s in ctx_slots]
    return np.array(v)
